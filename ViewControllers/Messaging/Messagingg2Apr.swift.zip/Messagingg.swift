//
//  Messaging.swift
//  TeleMedican
//
//  Created by IOS Dev on 02/05/2018.
//  Copyright © 2018 Paragon Marketing. All rights reserved.
//

import UIKit
import Alamofire
import AVFoundation
import GoogleMaps
import DropDown
import VHBoomMenuButton
import GoogleMaps
import GooglePlaces
import GooglePlacePicker
import FirebaseDatabase
import DropDown
import ContactsUI

//enum tag{
//    case incomming, outgoing
//}
//var msgviewtag = 0
//var arrmsg = [String]()
//var arrmsguser = [String]()

var receiverid = String()
@available(iOS 10.0, *)
class Messagingg: UIViewController, UITableViewDataSource, UITableViewDelegate, UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate, AVAudioRecorderDelegate, AVAudioPlayerDelegate, CLLocationManagerDelegate, GMSMapViewDelegate, GMSPlacePickerViewControllerDelegate, UIDocumentMenuDelegate,UIDocumentPickerDelegate, CNContactPickerDelegate, UIGestureRecognizerDelegate, BoomDelegate
{
    var groupId = String()
    var isviewloaad = 0
    var objecturl = ""
    var selectedimage = UIImage()
    
    var arrSelectedDeletIndex = [Int]()
    var temparrMsgId = NSMutableArray()
    var arrMsgFomid = NSMutableArray()
    var arrMsg = NSMutableArray()
    var arrMsgStatus = NSMutableArray()
    var arrMsgType = NSMutableArray()
    var arrMsgTime = NSMutableArray()
    var arrMsgPic = NSMutableArray()
    var arrMsgAudio = NSMutableArray()
    
    var arrMsgPicThumb = NSMutableArray()
    var arrMsgLat = NSMutableArray()
    var arrMsgLong = NSMutableArray()
    var arrMsgAddress = NSMutableArray()
    var arrMsgId = NSMutableArray()
    
    ///////////
    //MARK:- Delete Selection Parameters
    var iscopytext = 0
    var canDeleteEveryOne = 0
    
    //MAARK:- Dropdown
    let dropDown = DropDown()
    var selecteDict = [String: Any]()
    var refreshControl = UIRefreshControl()
    
    //MARK:- Location
    let locationManager = CLLocationManager()
    var userlat = Double()
    var userlong = Double()
    //MARK:- Picker
    let picker = UIImagePickerController()
    //var documentPicker = UIDocumentPickerViewController()
    
    var documentPicker = UIDocumentPickerViewController(documentTypes: ["com.apple.iwork.pages.pages", "com.apple.iwork.numbers.numbers", "com.apple.iwork.keynote.key","public.image", "com.apple.application", "public.item","public.data", "public.content", "public.audiovisual-content", "public.audiovisual-content", "public.text", "public.data", "public.zip-archive", "com.pkware.zip-archive", "public.composite-content", "public.text"], in: .import)
    var touid = String()
    var fromuid = String()
    var username = String()
    var userprofilepic = String()
    
    
    
    
    @IBOutlet weak var imgvCallDelete: UIImageView!
    @IBOutlet weak var imgvVideoCallCopy: UIImageView!
    @IBOutlet weak var imgvDotsFwd: UIImageView!
    
    
    @IBOutlet weak var btnAudioCall: UIButton!
    @IBAction func btnAudioCall(_ sender: Any) {
        if imgvCallDelete.image == UIImage.init(named: "trash")
        {
            //MARK:- Delete a User Messages
            //funDeleteSelectedMessages(isClear: 0, isDeleteEveryOne: isDeleteEveryOne)
            self.view.endEditing(true)
            objG.showDeletePopup(isDeleteForEveryOne: self.canDeleteEveryOne, viewController: self)
        }
        else
        {
            //MARK:- Call a user
        }
    }
    @IBOutlet weak var btnVideoCall: UIButton!
    @IBAction func btnVideoCall(_ sender: Any) {
        if imgvVideoCallCopy.image == UIImage.init(named: "copy")
        {
            //MARK:- User Message Copy
        }
        else if imgvVideoCallCopy.image == UIImage.init(named: "trash")
        {
            //MARK:- If multiple category selected like video text location audio etc
            //funDeleteSelectedMessages(isClear: 0, isDeleteEveryOne: isDeleteEveryOne)
            objG.showDeletePopup(isDeleteForEveryOne: self.canDeleteEveryOne, viewController: self)
        }
        else
        {
            //MARK:- Viceo Call a user
        }
    }
    func funDeleteSelectedMessages(isClear: Int, isDeletedFromEveryOne: Int)
    {
        if isClear == 1
        {
            if arrMsgId.count == 0
            {
                return
            }
        }
        andicator.startAnimating()
        var tempcount = 0
        var arrIndexes = arrSelectedDeletIndex
        temparrMsgId = arrMsgId
        if isClear == 1
        {
            arrIndexes += 0...arrMsgId.count - 1
        }
        
        arrSelectedDeletIndex = arrIndexes
        for i in arrIndexes
        {
            deleteMessages(index: i, isClear: isClear, isDeleteFromEveryOne: isDeletedFromEveryOne, completion: {response in
                print(response as Any)
                tempcount = tempcount + 1
                if tempcount ==  arrIndexes.count
                {
                    if isClear == 1
                    {
                        //MARK:- Clear All chat
                        self.arrMsgFomid = NSMutableArray()
                        self.arrMsg = NSMutableArray()
                        self.arrMsgType = NSMutableArray()
                        self.arrMsgTime = NSMutableArray()
                        self.arrMsgPicThumb = NSMutableArray()
                        self.arrMsgPic = NSMutableArray()
                        self.arrMsgAudio = NSMutableArray()
                        self.arrMsgLat = NSMutableArray()
                        self.arrMsgLong = NSMutableArray()
                        self.arrMsgAddress = NSMutableArray()
                        self.arrMsgId = NSMutableArray()
                        self.arrMsgStatus = NSMutableArray()
                    }
                    self.unSelectionMessages()
                    self.arrSelectedDeletIndex = [Int]()
                    DispatchQueue.main.async{
                         DispatchQueue.main.async{
                            self.tablev.reloadData()
                        }
                        self.andicator.stopAnimating()
                    }
                }
            })
        }
    }
    @IBOutlet weak var lblSelectionCount: UILabel!
    
    var dataarray = ["View Contacts", "Mute Notification", "Clear Chat"]
    @IBOutlet weak var btnDots: UIButton!
    @IBAction func btnDots(_ sender: Any) {
        dropDown.dataSource = dataarray
        dropDown.direction = .bottom
        dropDown.width = 140
        
        self.dropDown.anchorView = btnDots
        dropDown.show()
        self.dropDown.selectionAction = { [unowned self] (index: Int, item: String) in
            print("Selected item: \(item) at index: \(index)")
            self.dropDown.hide()
            //MARK:-
            switch self.dataarray[index] {
            
            case "View Contacts":
                let cnPicker = CNContactPickerViewController()
                cnPicker.delegate = self
                DispatchQueue.main.async {
                    self.present(cnPicker, animated: true, completion: nil)
                }
                break
            case "Mute Notification":
                
                break
            case "Clear Chat":
                self.funDeleteSelectedMessages(isClear: 1, isDeletedFromEveryOne: 0)
                break
            default:
                print("no match")
                break
            }
        }
    }
    
    var longPressGesture = UILongPressGestureRecognizer()
    var recordButton: UIButton!
    var recordingSession: AVAudioSession!
    var audioRecorder: AVAudioRecorder!
    var audiodata: Data!
    var playingurl = NSURL()
    var counttypingstatus = 0
    var audioplayerisplaying = "stop"
    var timeruseronline = Timer()
    var timeruseroffline = Timer()
    var timer_isonline = Timer()
    var clientid = String()
    var is_online = "0"
    var chatuserfullname = String()
    var receivertoken = String()
    var receiverimgurl = String()
    var messagetext = String()
    var imgdriwer = UIImage()
    var arrimages = [String]()
    var arrImagePlayPause = [String]()
    var arrTotalAudioTime = [String]()
    var driver_idForAwardReject = String()
    var selectedDict = NSDictionary()
    var ridestatus = String()
    var is_award = Bool()
    var updater : CADisplayLink! = nil
    
    
    @IBOutlet weak var tablev: UITableView!
    
    @IBOutlet weak var lblname: UILabel!
    @IBOutlet weak var imgv: UIImageView!
    @IBOutlet weak var lblstatus: UILabel!
    @IBOutlet weak var vnavigation: UIView!
    @IBOutlet var imgvhold: UIImageView!
    @IBOutlet var imgvmike: UIImageView!
    
    @IBOutlet var imgvattach: UIImageView!
    
    @IBOutlet weak var bgview: UIView!
    
    @IBOutlet weak var imgvuserstatus: UIImageView!
    @IBOutlet weak var btnback: UIButton!
    @IBAction func btnback(_ sender: Any) {
        if arrSelectedDeletIndex.count > 0
        {
            NotificationCenter.default.post(name: NSNotification.Name(rawValue: "removePopup"), object: nil)
            arrSelectedDeletIndex = [Int]()
            tablev.reloadData()
            unSelectionMessages()
            return
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    @IBOutlet weak var boombutton: BoomMenuButton!
    
    //MARK:- Not using in this app
    @IBOutlet weak var attachbutton: UIButton!
    @IBAction func buttonattach(_ sender: Any) {
        self.view.endEditing(true)
        picker.delegate = self
        picker.allowsEditing = false
        //        picker.sourceType = .photoLibrary
        //        //MRK: - if use .photolibrary photos and videso both will show when library open
        //        picker.mediaTypes = UIImagePickerController.availableMediaTypes(for: .savedPhotosAlbum)!
        //        present(picker, animated: true, completion: nil)
        
        let alert = UIAlertController(title: "Choose Image or Location", message: nil, preferredStyle: .actionSheet)
        alert.addAction(UIAlertAction(title: "Camera", style: .default, handler: { _ in
            self.openCamera()
        }))
        
        alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in
            self.openGallary()
        }))
        
        alert.addAction(UIAlertAction(title: "Share Location", style: .default, handler: { _ in
            self.confirmAlert()
        }))
        
        alert.addAction(UIAlertAction.init(title: "Cancel", style: .cancel, handler: nil))
        
        /*If you want work actionsheet on ipad
         then you have to use popoverPresentationController to present the actionsheet,
         otherwise app will crash on iPad */
        switch UIDevice.current.userInterfaceIdiom {
        case .pad:
            alert.popoverPresentationController?.sourceView = sender as? UIView
            alert.popoverPresentationController?.sourceRect = (sender as AnyObject).bounds
            alert.popoverPresentationController?.permittedArrowDirections = .up
        default:
            break
        }
        DispatchQueue.main.async {
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func confirmAlert()
    {
        let authorizationStatus = CLLocationManager.authorizationStatus()
        if (authorizationStatus == CLAuthorizationStatus.notDetermined) {
            self.locationManager.requestWhenInUseAuthorization()
        } else {
            self.locationManager.startUpdatingLocation()
        }
        let alertController = UIAlertController(title: "Current Location!", message: "Are you sure want to share your current location?", preferredStyle: UIAlertController.Style.alert)
        
        let subview = (alertController.view.subviews.first?.subviews.first?.subviews.first!)! as UIView
        subview.backgroundColor = UIColor.white
        
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel) { (result : UIAlertAction) -> Void in
            print("Cancel")
        }
        let okAction = UIAlertAction(title: "Share", style: UIAlertAction.Style.default) { (result : UIAlertAction) -> Void in
            //print(alertController.textFields?.first?.text)
            self.locationManager.delegate = self
            //MARK: - Check Authorization of map
            
            let authorizationStatus = CLLocationManager.authorizationStatus()
            if (authorizationStatus == CLAuthorizationStatus.notDetermined) {
                self.locationManager.requestWhenInUseAuthorization()
            } else {
                self.locationManager.startUpdatingLocation()
                DispatchQueue.main.async {
                    self.shareLocation()
                }
            }
        }
        alertController.addAction(cancelAction)
        alertController.addAction(okAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBOutlet weak var btncancel: UIButton!
    @IBOutlet weak var vimgselected: UIView!
    @IBOutlet weak var imgvselected: UIImageView!
    
    
    @IBOutlet weak var txtmsg: UITextField!
    @IBOutlet weak var btnsend: UIButton!
    @IBOutlet weak var andicator: UIActivityIndicatorView!
    @IBAction func btnsend(_ sender: Any) {
        
        if imgvmike.image == UIImage.init(named: "holdmike") || imgvmike.image == UIImage.init(named: "unholdmike")
        {
            
        }
        else
        {
            if txtmsg.text != ""
            {
                //andicator.startAnimating()
                sendMessage()
            }
            else if imgvselected.image != nil
            {
                //  andicator.startAnimating()
            }
            
        }
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        //msgviewtag = 0
        
        if  vnavigation.tag == 0
        {
            
            // ChatDB.child(fromuid).child(groupId).removeAllObservers()
            if groupId != ""
            {
                self.isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
                ChatDB.child(fromuid).child(groupId).removeAllObservers()
                MessagesDB.child(groupId).child(fromuid).removeAllObservers()
                MessagesDB.child(groupId).child(touid).removeAllObservers()
            }
            self.slidertimer.invalidate()
            NotificationCenter.default.removeObserver(self)
            defaults.setValue("0", forKey: "is_chatscreen")
            self.vnavigation.isHidden = true
            obj.showNavBar(viewcontroller: self)
            // timertypingstatus.invalidate()
        }
    }
    override func viewDidDisappear(_ animated: Bool) {
        if  vnavigation.tag == 0
        {
            //ChatDB.child(fromuid).child(groupId).removeAllObservers()
        }
    }
    override func viewWillAppear(_ animated: Bool) {
        self.vnavigation.isHidden = false
        txtmsg.delegate = self
        btnsend.addTarget(self, action: #selector(funholdRelease(sender:)), for: .touchUpInside);
        btnsend.addTarget(self, action: #selector(funHoldDown(sender:)), for: .touchDown)
        //If you want to add some thing perment in all view
        self.navigationController?.navigationBar.isHidden = true
        objG.statusbarcolor(viewcontroller: self)
        self.vnavigation.backgroundColor = appclr
        obj.hideNavBar(viewcontroller: self)
        if groupId != ""
        {
            
        }
    }
    override func viewDidAppear(_ animated: Bool) {
        self.tablev.frame.origin.y = vnavigation.frame.maxY + 5
        tablevheight = self.tablev.frame.size.height
        self.bgview.backgroundColor = UIColor.init(patternImage: UIImage.init(named: "chat_bg.png")!)
    }
    
    override func didReceiveMemoryWarning() {
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        defaults.setValue("1", forKey: "is_chatscreen")
        defaults.setValue("0", forKey: "is_message")
        
        //MARK:- Enable Speaker
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSession.Category.playAndRecord, mode: AVAudioSession.Mode.voiceChat, options: .defaultToSpeaker)
            try AVAudioSession.sharedInstance().overrideOutputAudioPort(.speaker)
            try AVAudioSession.sharedInstance().setActive(true)
        } catch _ {
            print("Error 2")
        }
        UIApplication.shared.keyWindow!.addSubview(self.vnavigation)
        // Do any additional setup after loading the view.
        
        locationManager.delegate = self
        let authorizationStatus = CLLocationManager.authorizationStatus()
        if (authorizationStatus == CLAuthorizationStatus.notDetermined) {
            self.locationManager.requestWhenInUseAuthorization()
        } else {
            self.locationManager.startUpdatingLocation()
        }
        arrMsg = NSMutableArray()
        // arrmsguser = [String]()
        //  msgviewtag = 1
        self.tablev?.tableFooterView = UIView()
        
        imgvhold.layer.cornerRadius = imgvhold.frame.size.height / 2
        //MARK:- Unimited rows in cell
        tablev.rowHeight = 128
        tablev.estimatedRowHeight = UITableView.automaticDimension
        registerForKeyboardNotifications()
        
        
        
        NotificationCenter.default.addObserver(self, selector: #selector(handleMsgNotificaions), name: NSNotification.Name(rawValue: "hideKeyboard"), object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(handleMsgNotificaions), name: NSNotification.Name(rawValue: "deleteMessages"), object: nil)
        
        
        // Back Button with image
        //        let backBtn = UIBarButtonItem(image: #imageLiteral(resourceName: "back2"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(funback))
        //        self.navigationItem.leftBarButtonItem = backBtn
        
        //        let refresh = UIBarButtonItem(image: UIImage.init(named: "refresh"), style: UIBarButtonItem.Style.plain, target: self, action: #selector(funrefresh))
        //        self.navigationItem.rightBarButtonItem = refresh
        
        //One image use multiple time for background
        
        //MARK:- Scroll to refresh
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(refresh(sender:)), for: UIControl.Event.valueChanged)
        tablev.addSubview(refreshControl) // not required when using UITableViewController
        
        
        funSetting()
    }
    
    func funSetting()
    {
        lblname.text = username
        imgv.kf.setImage(with: URL(string: userprofilepic))
        
        obj.setimageCircle(image: imgvuserstatus, viewcontroller: self)
        obj.setimageCircle(image: imgv, viewcontroller: self)
        
        obj.setBottomShadow(object: txtmsg)
        txtmsg.layer.borderWidth = 0.2
        txtmsg.layer.borderColor = UIColor.lightGray.cgColor
        txtmsg.layer.cornerRadius = txtmsg.frame.size.height / 2
        // imgvhold.backgroundColor = appclr
        
        //MARK;- Boom button Code
        self.boombutton.isUserInteractionEnabled = false
        boombutton.buttonEnum = .simpleCircle
        boombutton.piecePlaceEnum = .dot_6_1
        boombutton.buttonPlaceEnum = .sc_6_1
        //boombutton.duration = 1
        boombutton.hasBackground = false
        boombutton.boomDelegate = self
        imgvmike.center = imgvhold.center
        
        boombutton.target(forAction: #selector(funHideKeyboard), withSender: self)
        
        for i in 0..<boombutton.piecePlaceEnum.pieceNumber() {
            addBuilder(i: i)
        }
        
        
        DispatchQueue.main.async {
            obj.putRightViewinTextField(view: self.boombutton, txtfield: self.txtmsg, x: 0, width: 40, height: 40)
            Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { timer in
                print("Fire timer \(timer)")
                self.boombutton.isUserInteractionEnabled = true
                self.txtmsg.delegate = self
            }
        }
        //End Boom Button Code
        //
        if groupId != ""
        {
            self.retreiveMessages()
            
            //MARK:- When Chat Screen Run Frist time own Message Count should be Zero
            self.isdeliverWhenMsgScreenOpen()
        }
        else
        {
            retreivePrivateChatGroupId()
        }
        
        //MARK:- Add Long Gesture
        longPressGesture = UILongPressGestureRecognizer(target: self, action: #selector(longPressed))
        longPressGesture.minimumPressDuration = 1.0 // 1 second press
        longPressGesture.allowableMovement = 15 // 15 points
        longPressGesture.delegate = self
        self.tablev.addGestureRecognizer(longPressGesture)
        
        //MARK:- Register Cell for Send and Receive Message
        // Do any additional setup after loading the view.
        self.tablev.register(UINib(nibName: "ChatSendCell", bundle: nil), forCellReuseIdentifier: "ChatSendCell")
        self.tablev.register(UINib(nibName: "ChatReceiveCell", bundle: nil), forCellReuseIdentifier: "ChatReceiveCell")
        
        self.tablev.register(UINib(nibName: "SenderDeleteCell", bundle: nil), forCellReuseIdentifier: "SenderDeleteCell")
        self.tablev.register(UINib(nibName: "ReceiverDeleteCell", bundle: nil), forCellReuseIdentifier: "ReceiverDeleteCell")
        
        
    }
    
    let imageNames: [String] = ["searchboom","cameraboom","galleryboom","locationboom","audioboom","userboom","bee","bee"]
    func addBuilder(i : Int) {
        let builder = SimpleCircleButtonBuilder.init()
        //MARK- Boom Button Clicked Action
        builder.clickedClosure = { [weak self] (index: Int) in
            guard self != nil else { return }
            
            switch index {
            case 0:
                self!.openDocument()
                break
            case 1:
                self!.openCamera()
                break
            case 2:
                self!.openGallary()
                break
            case 3:
                self!.shareLocation()
                break
            case 4:
                self!.openAudio()
                break
            case 5:
                
                break
                
            default:
                break
            }
            // print(i)
        }
        builder.normalImageName = imageNames[i]
        boombutton.addBuilder(builder)
    }
    
    @objc func funHideKeyboard()
    {
        self.view.endEditing(true)
    }
    @objc func refresh(sender:AnyObject) {
        Timer.scheduledTimer(withTimeInterval: 2, repeats: false) { timer in
            print("Fire timer \(timer)")
            
            self.refreshControl.endRefreshing()
        }
        // Code to refresh table view
        
    }
    
    @objc func funrefresh()
    {
        
    }
    @objc func funback()
    {
        navigationController?.popViewController(animated: true)
    }
    
    
    
    //MARK:- Did Select Row
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if arrSelectedDeletIndex.count == 0
        {
            return
        }
        //MARK:- Select Unselect Table View Cells for Delete
        funTableSelectUnselect(indexPath: indexPath)
    }
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMsgType.count
    }
    func checkselecteindex(index: Int, view: UIView)
    {
        if arrSelectedDeletIndex.count > 0
        {
            if arrSelectedDeletIndex.contains(index)
            {
                view.isHidden = false
            }
            else
            {
                view.isHidden = true
            }
        }
        else
        {
            view.isHidden = true
        }
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //MARK:- This is Sender Cell which will display from Right Side
        //MARK:- If True its means self sended messages
        
        let timestring = obj.convertTimespamIntoTime(timestring: "\(arrMsgTime[indexPath.row] as! Int)")
        if arrMsgFomid[indexPath.row] as! String == fromuid
        {
            var statutype = Int()
            if let status = arrMsgStatus[indexPath.row] as? String
            {
                statutype = Int(status)!
            }
            else if let status = arrMsgStatus[indexPath.row] as? Int
            {
                statutype = status
            }
            
            //MARK:- Picture Message
            if arrMsgType[indexPath.row] as? Int == IMAGE
            {
                //MARK:- Sender Cell
                let cell = self.tablev.dequeueReusableCell(withIdentifier: "cellreceiverimg", for: indexPath) as! MessagingReceiverCell
                
                let url = URL(string: arrMsgPic[indexPath.row] as! String)
                cell.imgvreceiver.kf.setImage(with: url)
                cell.imgvbg.layer.cornerRadius = 6
                cell.imgv.layer.borderWidth = 1
                cell.imgv.layer.borderColor = UIColor.yellow.cgColor
                cell.imgv.layer.cornerRadius = cell.imgv.frame.size.height / 2
                //MARK:- Message Status Set
                self.setMessageStatusForCell(msgStatus: statutype, imageview: cell.imgvmsgstatus)
                
                obj.setImageViewShade(imageview: cell.imgvbg)
                
                cell.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell.vselection)
                return cell
            }
            else if arrMsgType[indexPath.row] as? Int == AUDIO
            {
                //MARK:- Voice Message
                //Receiver Cell
                let cell = self.tablev.dequeueReusableCell(withIdentifier: "cellreceivervoice", for: indexPath) as! MessagingReceiverCell
                
                cell.btnplay.tag = indexPath.row
                cell.btnplay.addTarget(self, action: #selector(funTapOnAudio(sender:)), for: .touchUpInside)
                
                cell.slider.tag = indexPath.row
                cell.slider.addTarget(self, action: #selector(seekBarValueChange), for: .valueChanged)
                cell.slider.isUserInteractionEnabled = false
                
                cell.lblcurrentvoicetime.text = "00:00"
                cell.lbltotalvoicetime.text = arrTotalAudioTime[indexPath.row]
                if arrImagePlayPause[indexPath.row] == "play"
                {
                    //cell.btnplay.setImage(UIImage.init(named:"play"), for: .normal)
                    obj.putImgInButtonWithOutLabelForCell(button: cell.btnplay, imgname: "play")
                }
                else
                {
                    //cell.btnplay.setImage (UIImage.init(named:"pause"), for: .normal)
                    obj.putImgInButtonWithOutLabelForCell(button: cell.btnplay, imgname: "pause")
                }
                //MARK:- Message Status Set
                self.setMessageStatusForCell(msgStatus: statutype, imageview: cell.imgvmsgstatus)
                obj.setImageViewShade(imageview: cell.imgvbg)
                
                cell.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell.vselection)
                return cell
            }
            else if arrMsgType[indexPath.row] as? Int == LOCATION
            {
                //MARK:- Location Message
                //MARK:- Sender Cell
                let cell = self.tablev.dequeueReusableCell(withIdentifier: "cellreceiverLocation", for: indexPath) as! MessagingReceiverCell
                
                
                cell.imgvbg.layer.cornerRadius = 6
                cell.imgv.layer.borderWidth = 1
                cell.imgv.layer.borderColor = UIColor.yellow.cgColor
                cell.imgv.layer.cornerRadius = cell.imgv.frame.size.height / 2
                if let templat = (arrMsgLat[indexPath.row] as? Double), let templong = (arrMsgLong[indexPath.row] as? Double)
                {
                    movetosaidlocation(lat: Double(templat), long: Double(templong), vformap: cell.vformap)
                }
                //MARK:- Message Status Set
                self.setMessageStatusForCell(msgStatus: statutype, imageview: cell.imgvmsgstatus)
                
                cell.btnmap.tag = indexPath.row
                cell.btnmap.addTarget(self, action: #selector(funRedirectGoogleNav), for: .touchUpInside)
                obj.setImageViewShade(imageview: cell.imgvbg)
                
                cell.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell.vselection)
                
                return cell
            }
            else
            {
                if statutype == MESSAGE_DELETED
                {//MARK:- If Message is deleted
                    let cell = self.tablev.dequeueReusableCell(withIdentifier: "SenderDeleteCell", for: indexPath) as! SenderDeleteCell
                    cell.lbltime.text = "\(timestring)"
                    cell.lblmsg.text = "You deleted this message"
                    cell.lblmsg.textColor = .lightGray
                    cell.lblmsg.font = UIFont.italicSystemFont(ofSize: 14)
                    obj.setImageViewShade(imageview: cell.vbg)
                    return cell
                }
                
                //MARK:- Text Messaage
                //Receiver Cell
                let cell = self.tablev.dequeueReusableCell(withIdentifier: "ChatSendCell", for: indexPath) as! ChatSendCell
                obj.labelunlimitedtext(label: cell.lblmsg)
                
                //MARK:- Message Status Set
                self.setMessageStatusForCell(msgStatus: statutype, imageview: cell.imgvmsgstatus)
                cell.lblmsg.text = arrMsg[indexPath.row] as? String
                cell.lblmsg.font = UIFont.boldSystemFont(ofSize: 15)
                
                cell.lblmsg.sizeToFit()
                cell.lbltime.text = "\(timestring)"
                obj.setImageViewShade(imageview: cell.vbg)
                
                checkselecteindex(index: indexPath.row, view: cell.vselection)
                return cell
            }
        }
        else
        {
            //MARK:-  its means Receive Messages from other user
            //MARK:- Picture Message
            if arrMsgType[indexPath.row] as? Int == IMAGE
            {
                //SEnder Cell
                let cell2 = self.tablev.dequeueReusableCell(withIdentifier: "cellsenderimg", for: indexPath) as! MessagingSenderCell
                cell2.imgv.image = selectedimage
                
                //cell2.imgv.image = UIImage.init(named: "user1")
                cell2.imgvbgpic.layer.cornerRadius = 6
                cell2.imgv.layer.borderWidth = 1
                cell2.imgv.layer.borderColor = UIColor.yellow.cgColor
                cell2.imgv.layer.cornerRadius = cell2.imgv.frame.size.height / 2
                
                if let tempurl = arrMsgPic[indexPath.row] as? String
                {
                    let url = URL(string: tempurl)
                    cell2.imgvsender.kf.setImage(with: url)
                }
                
                obj.setImageViewShade(imageview: cell2.imgvbgpic)
                
                cell2.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell2.vselection)
                return cell2
            }
            if arrMsgType[indexPath.row] as? Int == AUDIO
            {
                //MARK:- Receiver Cell
                let cell3 = self.tablev.dequeueReusableCell(withIdentifier: "cellsendervoice", for: indexPath) as! MessagingSenderCell
                //MARK:- Voice Message
                //SEnder Cell
                //let cell = self.tablev.dequeueReusableCell(withIdentifier: "cellsendervoice") as! MessagingSenderCell
                cell3.btnplay.tag = indexPath.row
                cell3.btnplay.addTarget(self, action: #selector(funTapOnAudio(sender:)), for: .touchUpInside)
                cell3.slider.tag = indexPath.row
                cell3.slider.addTarget(self, action: #selector(seekBarValueChange), for: .valueChanged)
                cell3.slider.isUserInteractionEnabled = false
               
                cell3.lblcurrentvoicetime.text = "00:00"
                cell3.lbltotalvoicetime.text = arrTotalAudioTime[indexPath.row]
                
                if arrImagePlayPause[indexPath.row] == "play"
                {
                    //cell3.btnplay.setImage(UIImage.init(named:"play"), for: .normal)
                    obj.putImgInButtonWithOutLabelForCell(button: cell3.btnplay, imgname: "play")
                }
                else
                {
                    // cell3.btnplay.setImage (UIImage.init(named:"pause"), for: .normal)
                    obj.putImgInButtonWithOutLabelForCell(button: cell3.btnplay, imgname: "pause")
                    
                }
                obj.setImageViewShade(imageview: cell3.imgvbg)
                cell3.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell3.vselection)
                return cell3
            }
            else if arrMsgType[indexPath.row] as? Int == LOCATION
            {
                //MARK:- Receiver Cell
                let cell4 = self.tablev.dequeueReusableCell(withIdentifier: "cellsenderLocation", for: indexPath) as! MessagingSenderCell
                cell4.imgv.image = selectedimage
                cell4.imgvbg.layer.cornerRadius = 6
                cell4.imgv.layer.borderWidth = 1
                cell4.imgv.layer.borderColor = UIColor.yellow.cgColor
                cell4.imgv.layer.cornerRadius = cell4.imgv.frame.size.height / 2
                if let templat = (arrMsgLat[indexPath.row] as? Double), let templong = (arrMsgLong[indexPath.row] as? Double)
                {
                    movetosaidlocation(lat: Double(templat), long: Double(templong), vformap: cell4.vformap)
                }
                
                cell4.btnmap.tag = indexPath.row
                cell4.btnmap.addTarget(self, action: #selector(funRedirectGoogleNav), for: .touchUpInside)
                obj.setImageViewShade(imageview: cell4.imgvbg)
                
                cell4.lbltime.text = "\(timestring)"
                checkselecteindex(index: indexPath.row, view: cell4.vselection)
                return cell4
            }
            else
            {
                if arrMsgStatus[indexPath.row] as? Int == MESSAGE_DELETED
                {//MARK:- If Message is deleted
                    let cell = self.tablev.dequeueReusableCell(withIdentifier: "ReceiverDeleteCell", for: indexPath) as! ReceiverDeleteCell
                    cell.lbltime.text = "\(timestring)"
                    cell.lblmsg.text = "User deleted this message"
                    cell.lblmsg.textColor = .lightGray
                    cell.lblmsg.font = UIFont.italicSystemFont(ofSize: 14)
                    obj.setImageViewShade(imageview: cell.vbg)
                    return cell
                }
                
                //MARK:- Text Message
//                //SEnder Cell

                let cell = self.tablev.dequeueReusableCell(withIdentifier: "ChatReceiveCell", for: indexPath) as! ChatReceiveCell
                obj.labelunlimitedtext(label: cell.lblmsg)
                if arrMsgStatus[indexPath.row] as? Int == MESSAGE_DELETED
                {
                    cell.lblmsg.text = "User deleted this message"
                }
                else
                {
                    //MARK:- Message Status Set
                    cell.lblmsg.text = arrMsg[indexPath.row] as? String
                }
                cell.lblmsg.sizeToFit()
                cell.lbltime.text = "\(timestring)"
                obj.setImageViewShade(imageview: cell.vbg)
                checkselecteindex(index: indexPath.row, view: cell.vselection)
                return cell
            }
        }
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat
    {
        return UITableView.automaticDimension
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat
    {
        if arrMsgType[indexPath.row] as? String == "\(IMAGE)" || arrMsgType[indexPath.row] as? Int == IMAGE || arrMsgType[indexPath.row] as? String == "\(LOCATION)" || arrMsgType[indexPath.row] as? Int == LOCATION
        {
            return 171
        }
        else if arrMsgType[indexPath.row] as? String == "\(AUDIO)" || arrMsgType[indexPath.row] as? Int == AUDIO
        {
            return 95
        }
        else
        {
            return UITableView.automaticDimension
        }
    }
    
    func setMessageStatusForCell(msgStatus: Int, imageview: UIImageView)
    {
        if msgStatus == NOT_DELIVERED
        {
            imageview.image = UIImage.init(named: "msgsent")
        }
        else if msgStatus == SENT
        {
            imageview.image = UIImage.init(named: "msgsent")
        }
        else if msgStatus == DELIVERED
        {
            imageview.image = UIImage.init(named: "msgdeliver")
        }
        else if msgStatus == SEEN
        {
            imageview.image = UIImage.init(named: "msgseen")
        }
    }
    
    //MARK:- Long Press Gesture
    @objc func longPressed(sender: UILongPressGestureRecognizer)
    {
        if sender.state == UIGestureRecognizer.State.ended {
            return
        }
        else if sender.state == UIGestureRecognizer.State.began
        {
            let p = sender.location(in: self.tablev)
            let indexPath = self.tablev.indexPathForRow(at: p)
            funTableSelectUnselect(indexPath: indexPath!)
        }else {
                print("Could not find index path")
        }
    }
    
    func funTableSelectUnselect(indexPath: IndexPath)
    {
         let index = indexPath
            // do stuff with your cell, for example print the indexPath
            print("longpressed Tag: \(index.row)")
            
            var selectunselect = 0
            if arrSelectedDeletIndex.contains(index.row) == true
            {
                let indexofcell = arrSelectedDeletIndex.firstIndex(of:index.row)
                arrSelectedDeletIndex.remove(at: indexofcell!)
                selectunselect = 1
            }else{
                arrSelectedDeletIndex.append(index.row)
                selectunselect = 0
            }
            if arrMsgFomid[index.row] as! String == defaults.value(forKey: "uid") as! String
            {
                //MARK:- Sender Cell
                if arrMsgType[indexPath.row] as? Int == TEXT
                {
                    let cell = self.tablev.cellForRow(at: index) as! ChatSendCell
                    tablev.beginUpdates()
                    if selectunselect == 1
                    {
                        cell.vselection.isHidden = true
                    }else{
                        cell.vselection.isHidden = false
                    }
                    tablev.endUpdates()
                }
                else
                {
                    let cell = self.tablev.cellForRow(at: index) as! MessagingReceiverCell
                    tablev.beginUpdates()
                    if selectunselect == 1
                    {
                        cell.vselection.isHidden = true
                    }else{
                        cell.vselection.isHidden = false
                    }
                    tablev.endUpdates()
                }
            }
            else
            {
                //MARK:- Receiver Cell
                if arrMsgType[indexPath.row] as? Int == TEXT
                {
                    let cell = self.tablev.cellForRow(at: index) as! ChatReceiveCell
                    tablev.beginUpdates()
                    if selectunselect == 1
                    {
                        cell.vselection.isHidden = true
                    }else{
                        cell.vselection.isHidden = false
                    }
                    tablev.endUpdates()
                }
                else
                {
                    let cell = self.tablev.cellForRow(at: index) as! MessagingSenderCell
                    tablev.beginUpdates()
                    if selectunselect == 1
                    {
                        cell.vselection.isHidden = true
                    }else{
                        cell.vselection.isHidden = false
                        //cell.contentView.backgroundColor = appclr.withAlphaComponent(0.15)
                    }
                    tablev.endUpdates()
                }
            }
        if arrSelectedDeletIndex.count > 0
        {
            selectionMessages()
        }
        else
        {
            unSelectionMessages()
        }
    }
    func selectionMessages()
    {
        imgv.isHidden = true
        lblstatus.isHidden = true
        lblname.isHidden = true
        lblSelectionCount.text = "\(arrSelectedDeletIndex.count) Selected"
        lblSelectionCount.isHidden = false
        imgvCallDelete.image = UIImage.init(named: "trash")
        imgvVideoCallCopy.image = UIImage.init(named: "copy")
        imgvDotsFwd.image = UIImage.init(named: "forward")
        //
        iscopytext = 1
        canDeleteEveryOne = 1
        for i in arrSelectedDeletIndex
        {
            if arrMsgType[i] as? Int == IMAGE || arrMsgType[i] as? Int == AUDIO || arrMsgType[i] as? Int == VIDEO || arrMsgType[i] as? Int == DOCUMENT || arrMsgType[i] as? Int == LOCATION
            {
                iscopytext = 0
            }
            
            let selected = obj.ifPreviousDateMessageSelect(timestring: "\(arrMsgTime[i] as! Int)")
            if selected == "0"
            {
                canDeleteEveryOne = 0
            }
            if arrMsgFomid[i] as! String == self.touid
            {
                canDeleteEveryOne = 0
            }
        }
        
        if iscopytext == 0
        {
            imgvCallDelete.isHidden = true
            imgvVideoCallCopy.image = UIImage.init(named: "trash")
        }
        else
        {
            imgvCallDelete.isHidden = false
            imgvVideoCallCopy.image = UIImage.init(named: "copy")
        }
        print("Total Selected Count: \(arrSelectedDeletIndex.count)")
    }
    func unSelectionMessages()
    {
        imgv.isHidden = false
        lblstatus.isHidden = false
        lblname.isHidden = false
        imgvCallDelete.isHidden = false
        lblSelectionCount.isHidden = true
        imgvCallDelete.image = UIImage.init(named: "callicon")
        imgvVideoCallCopy.image = UIImage.init(named: "video")
        imgvDotsFwd.image = UIImage.init(named: "dots")
    }
    //MARK:- Function table view scroll to bottom
    func scrolltobottom(indexpath: IndexPath)
    {
        self.tablev.scrollToRow(at: indexpath, at: .bottom, animated: true)
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        if keyboardtag == 1
        {
            //self.view.endEditing(true)
        }
    }
    
    //MARK:- Keyboard handle
    var activeField: UITextField?
    @IBOutlet var scrollView: UIScrollView!
    func registerForKeyboardNotifications(){
        //Adding notifies on keyboard appearing
        
        //Removing notifies on keyboard appearing
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.removeObserver(self, name: UIResponder.keyboardWillHideNotification, object: nil)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShowNotification(notification:)), name: UIResponder.keyboardWillShowNotification, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillBeHidden(notification:)), name: UIResponder.keyboardWillHideNotification, object: nil)
    }
    
    var keyboardtag = 0
    var tablevheight = CGFloat()
    @objc func keyboardWillShowNotification(notification: NSNotification){
        //Need to calculate keyboard exact size due to Apple suggestions
        // self.scrollView.isScrollEnabled = true
        
        var info = notification.userInfo!
        let keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        //let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, keyboardSize!.height, 0.0)
        
        
        self.tablev.frame.origin.y = vnavigation.frame.maxY + 5
        
        var aRect :CGRect = self.view.frame
        if let activeField = self.activeField {
            if activeField == txtmsg
            {
                // if (!(aRect.contains(activeField.frame.origin))){
                //self.view.frame = aRect
                if keyboardtag == 0
                {
                    // self.tablev.frame.size.height -= (keyboardSize!.height - 120)
                    self.view.frame.size.height = self.view.frame.size.height - (keyboardSize!.height)
                    self.tablev.frame.size.height = tablevheight - (keyboardSize!.height)//self.view.frame.size.height - 120
                    aRect.size.height -= keyboardSize!.height
                    keyboardtag = 1
                }
                // }
            }
            
        }
        if arrMsgType.count > 0
        {
            let indexPath = IndexPath(row: self.arrMsgType.count-1, section: 0)
            self.scrolltobottom(indexpath: indexPath)
        
        }
    }
    
    @objc func keyboardWillBeHidden(notification: NSNotification){
        //Once keyboard disappears, restore original positions
        var info = notification.userInfo!
        let keyboardSize = (info[UIResponder.keyboardFrameBeginUserInfoKey] as? NSValue)?.cgRectValue.size
        //let contentInsets : UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, -keyboardSize!.height, 0.0)
        
        self.tablev.frame.origin.y = vnavigation.frame.maxY + 5
        
        //self.view.frame = aRect
        if keyboardtag == 1
        {
            // self.view.frame.size.height = self.view.frame.size.height + (288)
            var aRect :CGRect = self.view.frame
            // self.view.endEditing(true)
            aRect.size.height += keyboardSize!.height
            self.view.frame.size.height = self.view.frame.size.height + (keyboardSize!.height)
            keyboardtag = 0
            DispatchQueue.main.async {
                self.tablev.frame.size.height = self.tablevheight
            }
        }
        if arrMsgType.count > 0
        {
            let indexPath = IndexPath(row: self.arrMsgType.count-1, section: 0)
               self.scrolltobottom(indexpath: indexPath)
            
        }
    }
    //MARK:- Boom Button Delegate when boom meny show
    func boomMenuButtonWillBoom(boomMenuButton bmb: BoomMenuButton) {
        self.view.endEditing(true)
    }
    
    //MARK:- Textfield Delegates
    func textFieldDidBeginEditing(_ textField: UITextField){
        activeField = textField
    }
    
    func textFieldDidEndEditing(_ textField: UITextField){
        activeField = nil
    }
    
    //MARK:- Textfield Delegates
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        self.view.endEditing(true)
        return true
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
    }
    func textFieldShouldEndEditing(_ textField: UITextField) -> Bool {
        counttypingstatus = 0
        //imgvmike.image = UIImage.init(named: "unholdmike")
        if groupId != ""
        {
            isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
        }
        return true
    }
    //MARK:- Textfield Delegates Did change char
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        
        let  char = string.cString(using: String.Encoding.utf8)!
        let isBackSpace = strcmp(char, "\\b")
        
        if (isBackSpace == -92) {
            print("Backspace was pressed")
            textField.text!.removeLast()
            if textField.text?.count == 0
            {
                counttypingstatus = 0
                imgvmike.image = UIImage.init(named: "unholdmike")
                if groupId != ""
                {
                    isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
                }
            }
            return false
        }
        
        let newLength = string.count
        if newLength > 0
        {
            if counttypingstatus == 0
            {
                counttypingstatus = 4
                timertypingstatus = Timer.scheduledTimer(withTimeInterval: 3, repeats: false) { [weak self] timer in
                    //                        self!.counttypingstatus -= 1
                    //                        if self?.counttypingstatus == 0 {
                    print("Go! Stop Typing")
                    
                    //MARK:- Check
                    if defaults.value(forKey: "is_chatscreen") as? String == "1"
                    {
                        print(self!.groupId)
                        if self!.groupId != ""
                        {
                            self!.counttypingstatus = 0
                            self!.updateOnline()
                            self!.isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
                        }
                        
                    }
                    else
                    {
                        return
                    }
                }
                imgvmike.image = UIImage.init(named: "send")
                if groupId != ""
                {
                    isTypingOrRecording(isTypingOrRecording: TYPING)
                }
            }else
            {
                counttypingstatus = 4
            }
        }
        if newLength == 0
        {
            counttypingstatus = 0
            if groupId != ""
            {
                isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
            }
            imgvmike.image = UIImage.init(named: "unholdmike")
            //SendAlert(text : "TypingStop", title: "TypingStop", content_type: true)
        }
        return true
    }
    
    
    
    
    func shareLocation()
    {
        //Hide keyboard
        self.view.endEditing(true)
        
        let center = CLLocationCoordinate2D(latitude: currentlat, longitude: currentlong)
        
        let islamabadzeropoint = CLLocationCoordinate2D(latitude: center.latitude + 0.01, longitude: center.longitude + 0.01)
        
        let rawalpindizeropoint = CLLocationCoordinate2D(latitude: center.latitude - 0.001, longitude: center.longitude - 0.001)
        let bounds = GMSCoordinateBounds(coordinate: islamabadzeropoint, coordinate: rawalpindizeropoint)
        
        //MARK: - Sample link is https://developers.google.com/places/ios-sdk/placepicker
        let config = GMSPlacePickerConfig(viewport: bounds)
        let placePicker = GMSPlacePickerViewController(config: config)
        placePicker.delegate = self
        
        present(placePicker, animated: true, completion: nil)
    }
    func openCamera()
    {
        self.picker.delegate = self
        if(UIImagePickerController .isSourceTypeAvailable(UIImagePickerController.SourceType.camera))
        {
            vnavigation.tag = 1
            picker.sourceType = UIImagePickerController.SourceType.camera
            picker.allowsEditing = true
            self.present(picker, animated: true, completion: nil)
            DispatchQueue.main.async {
                self.vnavigation.isHidden = true
            }
        }
        else
        {
            let alert  = UIAlertController(title: "Warning", message: "You don't have camera", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }
    }
    
    func openGallary()
    {
        self.picker.delegate = self
        vnavigation.tag = 1
        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
        DispatchQueue.main.async {
            self.vnavigation.isHidden = true
        }
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
            print("Fire timer \(timer)")
            obj.showNavBar(viewcontroller: self)
        }
    }
    
    func openDocument()
    {
        documentPicker.title = "documents"
        //documentPicker = UIDocumentPickerViewController(documentTypes: ["com.apple.iwork.pages.pages", "com.apple.iwork.numbers.numbers", "com.apple.iwork.keynote.key","public.image", "com.apple.application", "public.item","public.data", "public.content", "public.audiovisual-content", "public.movie", "public.audiovisual-content", "public.video", "public.audio", "public.text", "public.data", "public.zip-archive", "com.pkware.zip-archive", "public.composite-content", "public.text"], in: .import)
        documentPicker = UIDocumentPickerViewController(documentTypes: ["com.apple.iwork.pages.pages", "com.apple.iwork.numbers.numbers", "com.apple.iwork.keynote.key","public.image", "com.apple.application", "public.item","public.data", "public.content", "public.audiovisual-content", "public.audiovisual-content", "public.text", "public.data", "public.zip-archive", "com.pkware.zip-archive", "public.composite-content", "public.text"], in: .import)
        vnavigation.tag = 1
        DispatchQueue.main.async {
            self.vnavigation.isHidden = true
        }
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
            print("Fire timer \(timer)")
            obj.showNavBar(viewcontroller: self)
        }
    }
    
    func openAudio()
    {
        documentPicker.title = "audio"
        documentPicker = UIDocumentPickerViewController(documentTypes: ["public.audio"], in: .import)
        vnavigation.tag = 1
        DispatchQueue.main.async {
            self.vnavigation.isHidden = true
        }
        documentPicker.delegate = self
        present(documentPicker, animated: true, completion: nil)
        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
            print("Fire timer \(timer)")
            obj.showNavBar(viewcontroller: self)
        }
        
        //        self.picker.delegate = self
        //        vnavigation.tag = 1
        //        picker.sourceType = UIImagePickerController.SourceType.photoLibrary
        //        //picker.mediaTypes = kUTTypeAudio
        //        self.present(picker, animated: true, completion: nil)
        //        DispatchQueue.main.async {
        //            self.vnavigation.isHidden = true
        //        }
        //        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { timer in
        //            print("Fire timer \(timer)")
        //            obj.showNavBar(viewcontroller: self)
        //        }
    }
    //MARK:- Share Location Delegate
    //MARK:- Place Picker Delegates
    // To receive the results from the place picker 'self' will need to conform to
    // GMSPlacePickerViewControllerDelegate and implement this code.
    func placePicker(_ viewController: GMSPlacePickerViewController, didPick place: GMSPlace) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        //        print("Place name \(place.name)")
        //        print("Place address \(place.formattedAddress)")
        //        print("Place attributions \(place.attributions)")
        //
        userlat = place.coordinate.latitude
        userlong = place.coordinate.longitude
        if place.formattedAddress != nil
        {
            sendLocationMsg(address: place.formattedAddress!)
        }
        else
        {
            sendLocationMsg(address: "")
        }
    }
    func placePickerDidCancel(_ viewController: GMSPlacePickerViewController) {
        // Dismiss the place picker, as it cannot dismiss itself.
        viewController.dismiss(animated: true, completion: nil)
        
        print("No place selected")
    }
    
    ////image picker delegates
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
            //            imgvselected.image = pickedImage
            //            vimgselected.isHidden = false
            selectedimage = pickedImage
            imgvmike.image = UIImage.init(named: "send")
            self.sendPictureMsg()
        }
        else
        {
            
        }
        self.navigationController?.navigationBar.isHidden = true
        vnavigation.tag = 0
        vnavigation.isHidden = false
        dismiss(animated: true, completion: nil)
    }
    //image picker delegates
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.navigationController?.navigationBar.isHidden = true
        vnavigation.tag = 0
        vnavigation.isHidden = false
        dismiss(animated: true, completion: nil)
    }
    
    //MARK:- Documents Picker Delegates
    func documentMenu(_ documentMenu: UIDocumentMenuViewController, didPickDocumentPicker documentPicker: UIDocumentPickerViewController) {
        vnavigation.tag = 0
    }
    
    //MARK:- Documents Picker Delegates
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentAt url: URL) {
        vnavigation.tag = 0
    }
    //MARK:- Documents Picker Delegates
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("view was cancelled")
        dismiss(animated: true, completion: nil)
        
        vnavigation.tag = 0
    }
    var timertypingstatus = Timer()
    @objc func funtypingstatus()
    {
        if counttypingstatus == 0
        {
            
            // timertypingstatus.invalidate()
            counttypingstatus = 0
            updateOnline()
            //print(timertypingstatus)
            if groupId != ""
            {
                isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
                ChatDB.child(touid).child(groupId).updateChildValues(["typing": false])
            }
            
            return
        }
        counttypingstatus = counttypingstatus - 1
    }
    
    //target functions
    @objc func funHoldDown(sender:UIButton)
    {
        if imgvmike.image == UIImage.init(named: "holdmike") || imgvmike.image == UIImage.init(named: "unholdmike")
        {
            startRecording()
            DispatchQueue.main.async {
                if self.audioplayerisplaying != "stop"
                {
                    self.funStopPlayer(index: self.playeraudioindex, completion: {response in
                        print(response as Any)
                    })
                }
                self.txtmsg.attributedPlaceholder = NSAttributedString(string: "   Recording Audio...", attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
                //SendAlert(text: "VoiceRecStart", title: "VoiceRecStart", content_type: true)
                self.imgvmike.image = UIImage.init(named: "holdmike")
                
                if self.groupId != ""
                {
                    self.isTypingOrRecording(isTypingOrRecording: RECORDING)
                }
            }
        }
        // print("hold down")
    }
    
    @objc func funholdRelease(sender:UIButton)
    {
        //print("hold release")
        if imgvmike.image == UIImage.init(named: "holdmike") || imgvmike.image == UIImage.init(named: "unholdmike")
        {
            finishRecording(success: true)
            DispatchQueue.main.async {
                self.txtmsg.attributedPlaceholder = NSAttributedString(string: "   Type a message...",
                                                                       attributes: [NSAttributedString.Key.foregroundColor: UIColor.lightGray])
                //SendAlert(text: "VoiceRecStop", title: "VoiceRecStop", content_type: true)
                self.imgvmike.image = UIImage.init(named: "unholdmike")
                if self.groupId != ""
                {
                    self.isTypingOrRecording(isTypingOrRecording: STOP_TYPING_RECORDING)
                }
            }
        }
    }
    @objc func seekBarValueChange(sender:UISlider)
    {
        sender.isUserInteractionEnabled = true
        audioPlayer.currentTime = TimeInterval(sender.value)
        totalsecond = audioPlayer.currentTime
    }
    
    var timeraudiotyping = Timer()
    @objc func handleMsgNotificaions(notification: Notification)
    {
        if notification.name.rawValue == "deleteMessages"
        {
            let datadic = notification.object as! NSDictionary
            let isDeletedFromEveryOne = datadic.value(forKey: "isDeletedFromEveryOne") as! Int
            funDeleteSelectedMessages(isClear: 0, isDeletedFromEveryOne: isDeletedFromEveryOne)
        }
    }
    
    @objc func updateOnline()
    {
        lblstatus.text = "online"
    }
    @objc func updateTyping()
    {
        lblstatus.text = "Typing ..."
    }
    @objc func updateRecording()
    {
        lblstatus.text = "Recording ..."
    }
    @objc func updateTextFieldMsg()
    {
        txtmsg.text = ""
        imgvmike.image = UIImage.init(named: "unholdmike")
    }
    
    //MARK:- Online Ofline module Handling
    @objc func funUserIsOnline()
    {
        //SendAlert(text: "StatusOnline", title: "StatusOnline", content_type: true)
    }
    //    @objc func funOnlineStatus()
    //    {
    //        timeruseroffline.invalidate()
    //        timeruseronline.invalidate()
    //        timeruseronline = Timer.scheduledTimer(timeInterval: 60.0, target:self, selector: #selector(self.funUserIsOnline), userInfo: nil, repeats: false)
    //        timeruseroffline = Timer.scheduledTimer(timeInterval: 65.0, target:self, selector: #selector(self.funUserOffline), userInfo: nil, repeats: false)
    //    }
    @objc func funUserOffline()
    {
        imgvuserstatus.backgroundColor = UIColor.lightGray
        // funOnlineStatus()
    }
    //
    func funsettingvoice()
    {
        recordingSession = AVAudioSession.sharedInstance()
        do {
            //            if #available(iOS 10.0, *) {
            //                // try recordingSession.setCategory(.playAndRecord, mode: .default)
            //            } else {
            //                // Fallback on earlier versions
            //
            //            }
            try recordingSession.setActive(true)
            recordingSession.requestRecordPermission() { [unowned self] allowed in
                DispatchQueue.main.async {
                    
                    if allowed {
                        
                    } else {
                        // failed to record!
                    }
                }
            }
        } catch {
            // failed to record!
        }
    }
    
    func startRecording() {
        let audioFilename = getDocumentsDirectory().appendingPathComponent("recording.m4a")
        
        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilename, settings: settings)
            audioRecorder.delegate = self
            audioRecorder.record()
            
        } catch {
            finishRecording(success: false)
        }
    }
    
    func getDocumentsDirectory() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        return paths[0]
    }
    func finishRecording(success: Bool) {
        audioRecorder.stop()
        if let tempaudiodata = NSData(contentsOf: audioRecorder.url)
        {
            
            audiodata = Data()
            audiodata = tempaudiodata as Data
            
            DispatchQueue.main.async{
                self.sendAudioMsg(audio: self.audiodata)
            }
            //funVoiceImageUpload(text: "voice", title: "voice")
        }
        else
        {
            obj.showAlert(title: "Alert!", message: "Error in Recording", viewController: self)
        }
        //audioRecorder = nil
    }
    
    @objc func recordTapped() {
        if audioRecorder == nil {
            startRecording()
        } else {
            finishRecording(success: true)
        }
    }
    //var audioPlayer : AVAudioPlayer?
    var audioPlayer = AVAudioPlayer()
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        if !flag {
            finishRecording(success: false)
        }
        else
        {
            
        }
    }
    
    //            if audioPlayer.rate == 0
    //            {
    //                audioplayerisplaying = "pause"
    //                audioPlayer.pause()
    //            }
    //            else
    //            {
    //                audioplayerisplaying = "play"
    //                audioPlayer.play()
    //            }
    
    //MARK:- Handling audio in tableview cell when click on play or stop audio
    var playeraudioindex = 0
    @objc func funTapOnAudio(sender: UIButton)
    {
        let index = sender.tag
        if playeraudioindex == 0
        {
            if (audioplayerisplaying != "stop")
            {
                if playeraudioindex == index
                {
                    if (audioplayerisplaying == "play")
                    {
                        audioplayerisplaying = "pause"
                        audioPlayer.pause()
                    }
                    else
                    {
                        audioplayerisplaying = "play"
                        audioPlayer.play()
                    }
                    funTableViewCellRefresh(index: playeraudioindex)
                }
                else if playeraudioindex != index
                {
                    funStopPlayer(index: playeraudioindex, completion: {response in
                        print(response as Any)
                        self.playeraudioindex = index
                        self.funPlayAudio(index: index)
                    })
                }
                else
                {
                    playeraudioindex = index
                    funPlayAudio(index: index)
                }
            }
            else
            {
                playeraudioindex = index
                funPlayAudio(index: index)
            }
        }
        else if playeraudioindex == index
        {
            if (audioplayerisplaying == "play")
            {
                audioplayerisplaying = "pause"
                audioPlayer.pause()
            }
            else
            {
                audioplayerisplaying = "play"
                audioPlayer.play()
            }
            funTableViewCellRefresh(index: playeraudioindex)
        }
        else if playeraudioindex != index
        {
            funStopPlayer(index: playeraudioindex, completion: {response in
                print(response as Any)
                self.playeraudioindex = index
                self.funPlayAudio(index: index)
            })
        }
        else
        {
            playeraudioindex = index
            funPlayAudio(index: index)
        }
    }
    
    func funPlayAudio(index: Int)
    {
        let url = URL(string: arrMsgAudio[index] as! String)
        var error : NSError?
        
        if let err = error{
            print("audioPlayer error: \(err.localizedDescription)")
        }else{
            
            if (audioplayerisplaying == "play")
            {
                audioplayerisplaying = "pause"
                audioPlayer.pause()
                self.funTableViewCellRefresh(index: index)
            }
            else
            {
                var downloadTask:URLSessionDownloadTask
                downloadTask = URLSession.shared.downloadTask(with: url!, completionHandler: { [weak self](URL, response, error) -> Void in
                    do {
                        self?.playingurl = URL! as NSURL
                        self?.audioPlayer = try AVAudioPlayer(contentsOf: self!.playingurl as URL)
                    }
                    catch let error as NSError {
                        //self.player = nil
                        print(error.localizedDescription)
                    } catch {
                        print("AVAudioPlayer init failed")
                    }
                    self?.audioPlayer.prepareToPlay()
                    self!.audioPlayer.delegate = self
                    DispatchQueue.main.async {
                        self?.audioplayerisplaying = "play"
                        self?.audioPlayer.play()
                        self!.funTableViewCellRefresh(index: index)
                        self!.tablev.isUserInteractionEnabled = true
                    }
                })
                self.tablev.isUserInteractionEnabled = false
                downloadTask.resume()
            }
        }
    }
    
    
    func audioPlayerDidFinishPlaying(_ player: AVAudioPlayer, successfully flag: Bool)
    {
        funStopPlayer(index: playeraudioindex, completion: {response in
            print(response as Any)
        })
    }
    
    func funStopPlayer(index: Int,completion: @escaping (_ key: String?) -> Void) {

        playeraudioindex = 0
        self.audioplayerisplaying = "stop"
        audioPlayer.stop()
        //audioPlayer = AVAudioPlayer()
        audioRecorder = nil
        
        self.slidertimer.invalidate()
        self.slidertimer = Timer()
////        //MARK:- Add new row in table view
        let indexPath = IndexPath(row: index, section: 0)
        if arrMsgFomid[index] as! String == defaults.value(forKey: "uid") as! String
        {
            //MARK:- Sender Cell
            let cell = self.tablev.cellForRow(at: indexPath) as! MessagingReceiverCell
            cell.slider.setValue(0, animated: false)
            cell.lblcurrentvoicetime.text = "00:00"
        }
        else
        {
            //MARK:- Receiver Cell
            let cell = self.tablev.cellForRow(at: indexPath) as! MessagingSenderCell
            cell.slider.setValue(0, animated: false)
            cell.lblcurrentvoicetime.text = "00:00"
        }
        
//        tablev.endUpdates()
        //DispatchQueue.main.async {
        self.funTableViewCellRefresh(index: index)
        //}
         completion("success")
    }
    //MARK:- TableView Row Refresh
    func funTableViewCellRefresh(index: Int)
    {
        //MARK:- Add new row in table view
        let indexPath = IndexPath(row: index, section: 0)
        
        if arrMsgFomid[index] as! String == defaults.value(forKey: "uid") as! String
        {
            //MARK:- Sender Cell
            let cell = self.tablev.cellForRow(at: indexPath) as! MessagingReceiverCell
            if cell.btnplay.imageView?.image == UIImage.init(named: "play")
            {
                var cmTime = CMTime()
                var duration = CMTime()
                if self.audioplayerisplaying != "stop"
                {
                    cell.btnplay.setImage(UIImage.init(named: "pause"), for: .normal)
                    arrImagePlayPause[index] = "pause"
                    cmTime = CMTime(seconds: audioPlayer.duration, preferredTimescale: 1000000)
                    duration = cmTime
                    self.totalsecond = CMTimeGetSeconds(duration)
                    self.tablev.beginUpdates()
                    cell.slider.maximumValue = Float(self.totalsecond)
                    cell.slider.isUserInteractionEnabled = true
                    
                    obj.funhmsFrom(seconds: Int(self.totalsecond)) { hours, minutes, seconds in
                        
                        let hours = obj.getStringFrom(seconds: hours)
                        let minutes = obj.getStringFrom(seconds: minutes)
                        let secondss = obj.getStringFrom(seconds: seconds)
                        
                        //self.lbltimer.text = "\(hours):\(minutes):\(seconds)"
                        cell.lbltotalvoicetime.text = "\(minutes):\(secondss)"
                        self.arrTotalAudioTime[index] = "\(minutes):\(secondss)"
                        print("\(hours):\(minutes):\(secondss)")
                        self.slidertimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
                            self.totalsecond -= 0.05
                            if self.totalsecond <= 0 {
                                //print("Go!")
                                cell.slider.setValue(Float(0), animated: false)
                                self.slidertimer.invalidate()
                                self.tablev.endUpdates()
                            } else {
                                //  print("Slider: " + "\(self.sliderr.value)")
                                //  print("Player: " + "\(self.audioPlayer.currentTime)")
                                cell.lblcurrentvoicetime.text = self.updateSeekBar()
                                cell.slider.setValue(Float(self.audioPlayer.currentTime), animated: false)
                            }
                        }
                    }
                }
                else
                {
                    cell.btnplay.setImage(UIImage.init(named: "play"), for: .normal)
                    arrImagePlayPause[index] = "play"
                    totalsecond = 0
                    cell.slider.setValue(0, animated: false)
                    cell.lblcurrentvoicetime.text = "00:00"
                    tablev.endUpdates()
                }
            }
            else
            {
                self.slidertimer.invalidate()
                cell.btnplay.setImage(UIImage.init(named: "play"), for: .normal)
                arrImagePlayPause[index] = "play"
            }
        }
        else
        {
            //MARK:- Receiver Cell
            let cell = self.tablev.cellForRow(at: indexPath) as! MessagingSenderCell
            if cell.btnplay.imageView?.image == UIImage.init(named: "play")
            {
                var cmTime = CMTime()
                var duration = CMTime()
                if self.audioplayerisplaying != "stop"
                {
                    cell.btnplay.setImage(UIImage.init(named: "pause"), for: .normal)
                    arrImagePlayPause[index] = "pause"
                    cmTime = CMTime(seconds: audioPlayer.duration, preferredTimescale: 1000000)
                    duration = cmTime
                    self.totalsecond = CMTimeGetSeconds(duration)
                    self.tablev.beginUpdates()
                    cell.slider.maximumValue = Float(self.totalsecond)
                    cell.slider.isUserInteractionEnabled = true
                    
                    obj.funhmsFrom(seconds: Int(self.totalsecond)) { hours, minutes, seconds in
                        
                        let hours = obj.getStringFrom(seconds: hours)
                        let minutes = obj.getStringFrom(seconds: minutes)
                        let secondss = obj.getStringFrom(seconds: seconds)
                        
                        //self.lbltimer.text = "\(hours):\(minutes):\(seconds)"
                        cell.lbltotalvoicetime.text = "\(minutes):\(secondss)"
                        self.arrTotalAudioTime[index] = "\(minutes):\(secondss)"
                        print("\(hours):\(minutes):\(secondss)")
                        self.slidertimer = Timer.scheduledTimer(withTimeInterval: 0.05, repeats: true) { timer in
                            self.totalsecond -= 0.05
                            if self.totalsecond <= 0 {
                                //print("Go!")
                                cell.slider.setValue(Float(0), animated: false)
                                self.slidertimer.invalidate()
                                self.tablev.endUpdates()
                            } else {
                                //  print("Slider: " + "\(self.sliderr.value)")
                                //  print("Player: " + "\(self.audioPlayer.currentTime)")
                                cell.lblcurrentvoicetime.text = self.updateSeekBar()
                                cell.slider.setValue(Float(self.audioPlayer.currentTime), animated: false)
                            }
                        }
                    }
                }
                else
                {
                    cell.btnplay.setImage(UIImage.init(named: "play"), for: .normal)
                    arrImagePlayPause[index] = "play"
                    totalsecond = 0
                    cell.slider.setValue(0, animated: false)
                    cell.lblcurrentvoicetime.text = "00:00"
                    tablev.endUpdates()
                }
            }
            else
            {
                self.slidertimer.invalidate()
                cell.btnplay.setImage(UIImage.init(named: "play"), for: .normal)
                arrImagePlayPause[index] = "play"
            }
        }
        self.tablev.reloadRows(at: [indexPath], with: .none)
    }
    
    var totalsecond = Float64()
    var slidertimer = Timer()
    func updateSeekBar() -> String
    {
        let currentTime = Int(audioPlayer.currentTime)
        //let duration = Int(audioPlayer.duration)
        //let total = currentTime - duration
        //let totalString = String(total)
        
        let minutes = currentTime/60
        let seconds = currentTime - minutes / 60
        
        let playertime = NSString(format: "%02d:%02d", minutes,seconds) as String
        return playertime
    }
    
    var arrchatid = NSMutableArray()
    
    
    var arrrectoken = NSMutableArray()
    var arrrecid = NSMutableArray()
    var arrsendertoken = NSMutableArray()
    var arrsenderid = NSMutableArray()
    var arrtime = NSMutableArray()
    var arrpic = NSMutableArray()
    var arrvoice = NSMutableArray()
    var arrlat = NSMutableArray()
    var arrlong = NSMutableArray()
    
    
    var currentlat = Double()
    var currentlong = Double()
    var newLocation = CLLocation()
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        locationManager.stopUpdatingLocation()
        
        newLocation = (locations.last)!
        
        userlat = locations.first!.coordinate.latitude
        userlong = locations.first!.coordinate.longitude
        
        
        if let location = locations.first {
            
            currentlat = location.coordinate.latitude
            currentlong = location.coordinate.longitude
        }
    }
    
    //    func funAddMessage(_ snapshot: DataSnapshot)
    //    {
    //        print(snapshot)
    //        let indexPath = IndexPath(row: self.arrmsgtype.count-1, section: 0)
    //        //MARK:- Add new row in table view
    //        self.tablev.beginUpdates()
    //        self.tablev.insertRows(at: [IndexPath(row: self.arrmsgtype.count-1, section: 0)], with: .automatic)
    //        self.tablev.endUpdates()
    //        if arrmsgtype.count > 0
    //        {
    //            self.scrolltobottom(indexpath: indexPath)
    //        }
    //    }
    
    //MARK: - Function to move map to said location
    func movetosaidlocation(lat:Double , long: Double, vformap :GMSMapView)
    {
        vformap.delegate = self
        let center = CLLocationCoordinate2D(latitude: CLLocationDegrees(lat), longitude: CLLocationDegrees(long))
        vformap.camera = GMSCameraPosition(target: center, zoom: 11.2, bearing: 0, viewingAngle: 0)
        // 8
        locationManager.stopUpdatingLocation()
        
        vformap.settings.compassButton = true
        let marker = GMSMarker()
        marker.position = center
        marker.title = "Sender Location"
        marker.map = vformap
    }
    @objc func funRedirectGoogleNav(sender: UIButton)
    {
        //        if let url = URL(string: "https://maps.google.com") {
        //            UIApplication.shared.open(url, options: [:])
        //        }
        let tag = sender.tag
        
        if (UIApplication.shared.canOpenURL(NSURL(string:"https://maps.google.com")! as URL))
        {
            UIApplication.shared.open(URL(string: "https://maps.google.com/?q=@\(arrMsgLat[tag]),\(arrMsgLong[tag])")!)
        }
    }
    
    var autocreatedid = String()
    func sendMessage()
    {
        andicator.startAnimating()
        autocreatedid = MessagesDB.childByAutoId().key!
        
        //        let dic1 = [fromuid:["\(autocreatedid)" : [
        //        "from":"\(fromuid)",
        //        "message":txtmsg.text!,
        //        "messageStatus":"0",
        //        "messageType":"1",
        //        "timestamp": timespam]]]
        //
        //        let dic2 = [touid:["\(autocreatedid)" : [
        //        "from":"\(fromuid)",
        //        "message":txtmsg.text!,
        //        "messageStatus":"0",
        //        "messageType":"1",
        //        "timestamp": timespam]]]
        
        if groupId.isEmpty == true
        {
            funCreateNewChat(msgType: TEXT)
        }
        else
        {
            //MARK:- Groupid already exist just send message
            self.createChat(msgtype: TEXT, key: groupId, ifupdate: "1", completion: {
                response in
                self.andicator.stopAnimating()
                if response == "success"
                {
                    //   self.MessagesDB.child(self.groupId).setValuesForKeys(dicmsg)
                    //  self.MessagesDB.child(self.groupId).updateChildValues([[self.fromuid:dic1]: [self.touid:dic2]], withCompletionBlock: {_,_ in })
                    //MAARK:- Need to improve this
                    // let timespam = "\(Int64(Date().timeIntervalSince1970 * 1000))"
                    
                    let timespam = Date().currentTimeMillis()!
                    //print(timespam)
                    MessagesDB.child(self.groupId).child(self.fromuid).child(self.autocreatedid).setValue([
                        "from":"\(self.fromuid)",
                        "message":self.txtmsg.text!,
                        "messageStatus":NOT_DELIVERED,
                        "messageType":TEXT,
                        "timestamp": timespam])
                    MessagesDB.child(self.groupId).child(self.touid).child(self.autocreatedid).setValue([
                        "from":"\(self.fromuid)",
                        "message":self.txtmsg.text!,
                        "messageStatus":NOT_DELIVERED,
                        "messageType":TEXT,
                        "timestamp": timespam] as [String : Any], withCompletionBlock: {
                            error, ref in
                            self.andicator.stopAnimating()
                            if error == nil
                            {
                                // self.isdeliver(messageStatus: SENT)
                                //MARK:- Uncomment the upper line for testing the unSeenCount
                                obj.showToast(message: "Message send successfully.", viewcontroller: self)
                                self.updateTextFieldMsg()
                            }
                    })
                    
                    //                    self.MessagesDB.child(self.groupId).updateChildValues(dicmsg, withCompletionBlock: {
                    //                        error, snapshot in
                    ////                    self.MessagesDB.child(self.groupId).setValue(dicmsg, withCompletionBlock: { error, snapshot in
                    //                        print(snapshot)
                    //                        self.andicator.stopAnimating()
                    //                        if error != nil
                    //                        {
                    //                            obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                    //                        }
                    //                        else
                    //                        {
                    //                            obj.showToast(message: "Message send successfully.", viewcontroller: self)
                    //                        }
                    //                    })
                }
                else
                {
                    //MARK:- From
                    obj.showToast(message: response!, viewcontroller: self)
                }
            })
        }
    }
    
    func sendPictureMsg()
    {
        andicator.startAnimating()
        autocreatedid = MessagesDB.childByAutoId().key!
        if groupId.isEmpty == true
        {
            funCreateNewChat(msgType: IMAGE)
        }
        else
        {
            //MARK:- Groupid already exist just send message
            self.createChat(msgtype: IMAGE, key: groupId, ifupdate: "1", completion: {
                response in
                self.andicator.stopAnimating()
                if response == "success"
                {
                    //MAARK:- Need to improve this
                    let timespam = Date().currentTimeMillis()!
                    self.uploadMedia(type: IMAGE) { url in
                        guard let url = url else { return }
                        self.objecturl = url
                        let dicfromto = [
                            "from":"\(self.fromuid)",
                            "imageThumb":self.objecturl,
                            "message":self.txtmsg.text!,
                            "messageImagePath":self.objecturl,
                            "messageStatus":NOT_DELIVERED,
                            "messageType":IMAGE,
                            "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                            "timestamp": timespam] as [String : Any]
                        self.andicator.startAnimating()
                        MessagesDB.child(self.groupId).child(self.fromuid).child(self.autocreatedid).setValue(dicfromto
                            as [String :Any],withCompletionBlock: {
                                error, ref in
                                self.andicator.stopAnimating()
                                if error != nil
                                {
                                    obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                                }
                                else
                                {
                                    MessagesDB.child(self.groupId).child(self.touid).child(self.autocreatedid).setValue(dicfromto)
                                    obj.showToast(message: "Picture send successfully.", viewcontroller: self)
                                }
                        })
                    }
                    
                }
                else
                {
                    //MARK:- From
                    obj.showToast(message: response!, viewcontroller: self)
                }
            })
        }
    }
    func sendLocationMsg(address: String)
    {
        andicator.startAnimating()
        autocreatedid = MessagesDB.childByAutoId().key!
        if groupId.isEmpty == true
        {
            funCreateNewChat(msgType: LOCATION)
        }
        else
        {
            //MARK:- Groupid already exist just send message
            self.createChat(msgtype: LOCATION, key: groupId, ifupdate: "1", completion: {
                response in
                self.andicator.stopAnimating()
                if response == "success"
                {
                    //   self.MessagesDB.child(self.groupId).setValuesForKeys(dicmsg)
                    //  self.MessagesDB.child(self.groupId).updateChildValues([[self.fromuid:dic1]: [self.touid:dic2]], withCompletionBlock: {_,_ in })
                    //MAARK:- Need to improve this
                    let timespam = Date().currentTimeMillis()!
                    MessagesDB.child(self.groupId).child(self.fromuid).child(self.autocreatedid).setValue(["from":"\(self.fromuid)",
                        "imageThumb":"",
                        "latitude":self.currentlat,
                        "longitude":self.currentlong,
                        "address":address,
                        "message":self.txtmsg.text!,
                        "messageImagePath":"",
                        "messageStatus":NOT_DELIVERED,
                        "messageType":LOCATION,
                        "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                        "timestamp": timespam] as [String : Any], withCompletionBlock: {
                            error, snapshot in
                            self.andicator.stopAnimating()
                            if error == nil
                            {
                                //asdf
                                MessagesDB.child(self.groupId).child(self.fromuid).child(snapshot.key!).observe(.value) { (snapshot : DataSnapshot) in
                                    MessagesDB.child(self.groupId).child(self.fromuid).child(snapshot.key).removeAllObservers()
                                    self.funaddvalue(snapShotValue: snapshot.value as! NSDictionary, snapshotkey: snapshot.key)
                                    self.tablev.reloadData()
                                }
                                
                            }
                    })
                            
                            MessagesDB.child(self.groupId).child(self.touid).child(self.autocreatedid).setValue(["from":"\(self.fromuid)",
                        "imageThumb":"",
                        "latitude":self.currentlat,
                        "longitude":self.currentlong,
                        "address":address,
                        "message":self.txtmsg.text!,
                        "messageImagePath":"",
                        "messageStatus":NOT_DELIVERED,
                        "messageType":LOCATION,
                        "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                        "timestamp": timespam] as [String : Any], withCompletionBlock: {
                            error, ref in
                            self.andicator.stopAnimating()
                            if error == nil
                            {
                                // self.isdeliver(messageStatus: SENT)
                                //MARK:- Uncomment the upper line for testing the unSeenCount
                                obj.showToast(message: "Message send successfully.", viewcontroller: self)
                                self.updateTextFieldMsg()
                            }
                    })
                    obj.showToast(message: "Location send successfully.", viewcontroller: self)
                }
                else
                {
                    //MARK:- From
                    obj.showToast(message: response!, viewcontroller: self)
                }
            })
        }
    }
    func sendAudioMsg(audio: Data)
    {
        andicator.startAnimating()
        autocreatedid = MessagesDB.childByAutoId().key!
        if groupId.isEmpty == true
        {
            funCreateNewChat(msgType: AUDIO)
        }
        else
        {
            //MARK:- Groupid already exist just send message
            self.createChat(msgtype: AUDIO, key: groupId, ifupdate: "1", completion: {
                response in
                self.andicator.stopAnimating()
                if response == "success"
                {
                    //MAARK:- Need to improve this
                    let timespam = Date().currentTimeMillis()!
                    self.uploadMedia(type: AUDIO) { url in
                        guard let url = url else { return }
                        self.objecturl = url
                        let dicfromto = [
                            "from":"\(self.fromuid)",
                            "message":self.txtmsg.text!,
                            "messageAudioFile":self.objecturl,
                            "messageStatus":NOT_DELIVERED,
                            "messageType":AUDIO,
                            "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                            "timestamp": timespam] as [String : Any]
                        self.andicator.startAnimating()
                        MessagesDB.child(self.groupId).child(self.fromuid).child(self.autocreatedid).setValue(dicfromto
                            as [String :Any],withCompletionBlock: {
                                error, ref in
                                self.andicator.stopAnimating()
                                if error != nil
                                {
                                    obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                                }
                                else
                                {
                                    MessagesDB.child(self.groupId).child(self.touid).child(self.autocreatedid).setValue(dicfromto)
                                    obj.showToast(message: "Audio send successfully.", viewcontroller: self)
                                }
                        })
                    }
                }
                else
                {
                    //MARK:- From
                    obj.showToast(message: response!, viewcontroller: self)
                }
            })
        }
    }
    func funCreateNewChat(msgType: Int)
    {
        let timespam = Date().currentTimeMillis()!
        var dicmsg = [String: Any]()
        switch (msgType) {
        case (TEXT):
            dicmsg = [
                fromuid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "message":txtmsg.text!,
                    "messageStatus":NOT_DELIVERED,
                    "messageType":TEXT,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]],
                
                touid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "message":txtmsg.text!,
                    "messageStatus":NOT_DELIVERED,
                    "messageType":TEXT,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]]
            ]
            break
        case (LOCATION):
            dicmsg = [
                fromuid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "imageThumb":"",
                    "latitude":currentlat,
                    "longitude":currentlong,
                    "message":txtmsg.text!,
                    "messageImagePath":"",
                    "messageStatus":NOT_DELIVERED,
                    "messageType":LOCATION,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]],
                
                touid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "imageThumb":"",
                    "latitude":currentlat,
                    "longitude":currentlong,
                    "message":txtmsg.text!,
                    "messageImagePath":"",
                    "messageStatus":NOT_DELIVERED,
                    "messageType":LOCATION,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]]
            ]
            break
        case (IMAGE):
            dicmsg = [
                fromuid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "imageThumb":"\(objecturl)",
                    "message":txtmsg.text!,
                    "messageImagePath":"",
                    "messageStatus":NOT_DELIVERED,
                    "messageType":IMAGE,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]],
                
                touid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "imageThumb":"\(objecturl)",
                    "message":txtmsg.text!,
                    "messageImagePath":"",
                    "messageStatus":NOT_DELIVERED,
                    "messageType":IMAGE,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]]
            ]
            break
        case AUDIO:
            dicmsg = [
                fromuid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "message":txtmsg.text!,
                    "messageAudioFile":objecturl,
                    "messageStatus":NOT_DELIVERED,
                    "messageType":AUDIO,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]],
                
                touid: [autocreatedid : [
                    "from":"\(fromuid)",
                    "message":txtmsg.text!,
                    "messageAudioFile":objecturl,
                    "messageStatus":NOT_DELIVERED,
                    "messageType":AUDIO,
                    "phoneNumber":defaults.value(forKey: "phoneno") as! String,
                    "timestamp": timespam]]
            ]
            break
        case VIDEO:
            
            break
        default:
            print("dfggf")
        }
        
        //MARK:- Create new groupid and send message
        createNewPrivateChatGroupId(msgtype: msgType){ key in
            self.andicator.stopAnimating()
            guard let key = key else {
                obj.showToast(message: "Error Occured try again!", viewcontroller: self)
                return }
            if self.groupId == ""
            {
                obj.showToast(message: key, viewcontroller: self)
            }
            else
            {
                if msgType == TEXT || msgType == LOCATION
                {
                    MessagesDB.child(key).setValue(dicmsg, withCompletionBlock: { error, snapshot in
                        print(snapshot)
                        
                        if error != nil
                        {
                            obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                        }
                        else
                        {
                            self.txtmsg.text = ""
                            self.imgvmike.image = UIImage.init(named: "unholdmike")
                            obj.showToast(message: "Message send successfully.", viewcontroller: self)
                        }
                    })
                }
                else
                {
                    self.uploadMedia(type: msgType) { url in
                        guard let url = url else { return }
                        self.objecturl = url
                        MessagesDB.child(key).setValue(dicmsg
                            as [String :Any],withCompletionBlock: {
                                error, ref in
                                self.andicator.stopAnimating()
                                if error != nil
                                {
                                    obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                                }
                                else
                                {
                                    obj.showToast(message: "Message send successfully.", viewcontroller: self)
                                }
                        })
                    }
                }
                
            }
        }
    }
    //MARK:- if you have send first message to receiver and no Private Chat Group Id Exist
    func createNewPrivateChatGroupId(msgtype: Int,completion: @escaping (_ key: String?) -> Void) {
        //MARK:- Add new group
        let timespam = Date().currentTimeMillis()!
        let dicGroup = [
            "groupCreatedAt" : timespam,
            "groupCreatedBy" : timespam,
            "groupDescription" : "",
            "groupImage" : "",
            "groupName" : "\(self.fromuid),\(self.touid)",
            "groupType" : "Private Chat",
            "groupUpdated" : timespam] as [String : Any]
        
        GroupsDB.childByAutoId().setValue(dicGroup ,withCompletionBlock: {
            error, snapshot in
            print(snapshot)
            if error != nil
            {
                completion(error?.localizedDescription)
            }
            else
            {
                //MARK:- From
                let fromdic =  [self.touid:
                    ["groupId": "\(String(describing: snapshot.key!))"]]
                
                let todic =  [self.fromuid:
                    ["groupId": "\(String(describing: snapshot.key!))"]]
                
                //MARK:- Add data in Private Chat with Group id
                PrivateChatDB.child(self.fromuid).updateChildValues(fromdic,withCompletionBlock: {
                    error, ref in
                    if error != nil
                    {
                        completion(error?.localizedDescription)
                    }
                    else
                    {
                        PrivateChatDB.child(self.touid).updateChildValues(todic, withCompletionBlock: {
                            
                            error, ref in
                            if error != nil
                            {
                                completion(error?.localizedDescription)
                            }
                            else
                            {
                                self.createChat(msgtype: msgtype, key: snapshot.key!, ifupdate: "0", completion: {
                                    response in
                                    if response != "success"
                                    {
                                        completion(response)
                                    }
                                    else
                                    {
                                        //MARK:- Observer on Gouped ID Messageses
                                        if self.groupId == ""
                                        {
                                            //MARK:- From
                                            self.groupId = snapshot.key!
                                            self.retreiveMessages()
                                            self.funUserActivityStatus()
                                        }
                                        completion(snapshot.key)
                                    }
                                })
                            }
                        })
                    }})
            }
            //MARK:-v1- From and 2- To both
            //            self.PrivateChatDB.child(self.fromuid).child(self.touid).setValue(dicgroupId)
            //            self.PrivateChatDB.child(self.touid).child(self.fromuid).setValue(dicgroupId)
        })
    }
    
    func createChat(msgtype: Int,key: String,ifupdate: String, completion: @escaping (_ key: String?) -> Void) {
        let timespam = Date().currentTimeMillis()!
        funGetMessageCount(completion: {
            unSeenCount in
            let dicGroupFrom = [
                "createdAt" : timespam,
                "groupType" : "Private Chat",
                "lastMessage" : self.txtmsg.text!,
                "lastMessageId" : self.autocreatedid,
                "lastMessageStatus" : NOT_DELIVERED,
                "lastMessageTime" : timespam,
                "lastMessageType" : msgtype,
                "lastMessageUserId" : self.fromuid,
                "messageStatus" : "",
                "otherUserId" : self.touid,
                "seen" : false,
                "typing" : STOP_TYPING_RECORDING,
                "userPhoneNumber" : defaults.value(forKey: "phoneno") as! String,
                "unSeenCount":0] as [String : Any]
            let dicGroupTo = [
                "createdAt" : timespam,
                "groupType" : "Private Chat",
                "lastMessage" : self.txtmsg.text!,
                "lastMessageId" : self.autocreatedid,
                "lastMessageStatus" : NOT_DELIVERED,
                "lastMessageTime" : timespam,
                "lastMessageType" : msgtype,
                "lastMessageUserId" : self.fromuid,
                "messageStatus" : "",
                "otherUserId" : self.fromuid,
                "seen" : false,
                "typing" : STOP_TYPING_RECORDING,
                "userPhoneNumber" : defaults.value(forKey: "phoneno") as! String,
                "unSeenCount": unSeenCount as Any] as [String : Any]
            
            ChatDB.child(self.fromuid).child(key).updateChildValues(dicGroupFrom, withCompletionBlock: {
                error, snapshot in
                if error != nil
                {
                    completion(error?.localizedDescription)
                }
                else
                {
                    ChatDB.child(self.touid).child(key).updateChildValues(dicGroupTo)
                    completion("success")
                }
            })
        })
        
    }
    
    //MARK:- Delete Messages
    func deleteMessages(index: Int, isClear: Int, isDeleteFromEveryOne: Int, completion: @escaping (_ key: String?) -> Void) {
        print("deleting index: \(index)")
   
        let msgid = temparrMsgId[index] as! String
   
        if isDeleteFromEveryOne == 0
        {
            MessagesDB.child(groupId).child(fromuid).child(msgid).removeValue(completionBlock: { error, snapshot in
                
                if error != nil
                {
                    obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                    completion("fail")
                }
                else
                {
                    let index = self.arrMsgId.index(of: snapshot.key as Any)
                    
                    self.arrMsgFomid.removeObject(at: index)
                    self.arrMsg.removeObject(at: index)
                    self.arrMsgType.removeObject(at: index)
                    self.arrMsgTime.removeObject(at: index)
                    self.arrMsgPicThumb.removeObject(at: index)
                    self.arrMsgPic.removeObject(at: index)
                    self.arrMsgAudio.removeObject(at: index)
                    self.arrMsgLat.removeObject(at: index)
                    self.arrMsgLong.removeObject(at: index)
                    self.arrMsgAddress.removeObject(at: index)
                    self.arrMsgId.removeObject(at: index)
                    self.arrMsgStatus.removeObject(at: index)
                    
                    let indexPath = IndexPath(row: index, section: 0)
                    self.tablev.deleteRows(at: [indexPath], with: .fade)
                    
                    completion("success")
                }
            })
        }
        else
        {
            if arrMsgId[index] as! String == arrMsgId[arrMsgId.count - 1] as! String
            {
                isSelfdeliver(messageStatus: MESSAGE_DELETED)
                isdeliver(messageStatus: MESSAGE_DELETED)
            }
            MessagesDB.child(self.groupId).child(self.touid).child(msgid)
                .updateChildValues([
                    "messageStatus":MESSAGE_DELETED],
                     withCompletionBlock: { error, snapshot in
                        
                        if error != nil
                        {
                            obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                            completion("fail")
                        }
                        else
                        {
                            
                            completion("success")
                        }
                })
            
            MessagesDB.child(groupId).child(fromuid).child(msgid)
                .updateChildValues([
                    "messageStatus":MESSAGE_DELETED,
                    ], withCompletionBlock: { error, snapshot in
                
                if error != nil
                {
                    obj.showToast(message: (error?.localizedDescription)!, viewcontroller: self)
                    completion("fail")
                }
                else
                {
                    if isDeleteFromEveryOne == 1
                    {
                        //MARK:- If other User Message Delete
                        
                    }
                    
                    if isClear == 1
                    {
                        completion("success")
                        return
                    }
                    completion("success")
                }
            })
        }
        
    }
    //Mark:- if you already have send any message to receiver then group id will find
    func retreivePrivateChatGroupId(){
        //Firebase Fetch Query
        //MARK:- How to get a single valuee by key and again in this node get another single value
        PrivateChatDB.child(fromuid).child(touid).observeSingleEvent(of: .value, with: { (snapshot) in
            print(snapshot)
            if snapshot.childrenCount > 0
            {
                print(snapshot)
                
                if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                    for snap in snapShot{
                        if let gid = snap.value as? String{
                            if self.groupId == ""
                            {
                                self.groupId = gid
                                DispatchQueue.main.async {
                                    self.retreiveMessages()
                                    self.funUserActivityStatus()
                                }
                            }
                        }
                        break
                    }
                }
            }
        })
    }
    
    
    //MARK:- Retreive Messages from db and add observer
    var totalmessagecount = 0
    func retreiveMessages(){
        MessagesDB.child(groupId).child(fromuid).queryOrderedByKey().observe(.value) { (snapshot) in
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                MessagesDB.child(self.groupId).child(self.fromuid).removeAllObservers()
                self.funMessageDBDeliveryStatus()
                if snapShot.count > 0
                {
                    self.andicator.startAnimating()
                    self.totalmessagecount = Int(snapshot.childrenCount)
                    print(snapShot)
                    //MARK:- WHEN I USE THIS DATADIC  sortting issue occur
                    let datadic = (snapshot.value as! NSDictionary).allValues as NSArray
                    
                    if datadic.count > 0
                    {
                        if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                            
                            for snap in snapShot{
                                if let data = snap.value as? [String:AnyObject]{
                                    
                                    self.funaddvalue(snapShotValue: data as NSDictionary, snapshotkey: snap.key)
                                    self.arrImagePlayPause.append("play")
                                    self.arrTotalAudioTime.append("00:00")
                                }
                            }
                           // print(self.arrMsg)
                        }
                    }
                    
                    self.tablev.reloadData(){
                        self.funReceiveMessage()
                        let indexPath = IndexPath(row: self.arrMsgType.count-1, section: 0)
                        self.scrolltobottom(indexpath: indexPath)
                        self.andicator.stopAnimating()
                        
                    }
                }
                else
                {
                    self.isviewloaad = 1
                    self.funReceiveMessage()
                }
            }
        }
    }
    func funaddvalue(snapShotValue: NSDictionary, snapshotkey: String)
    {
        print(snapShotValue)
        self.arrMsgFomid.add(snapShotValue.value(forKey: "from") as! String)
        
        self.arrMsg.add(snapShotValue.value(forKey: "message") as! String)
        if let type = snapShotValue.value(forKey: "messageType") as? String
        {
            self.arrMsgType.add(type)
        }
        else if let type = snapShotValue.value(forKey: "messageType") as? Int
        {
            self.arrMsgType.add(type)
        }
        if let time = snapShotValue.value(forKey: "timestamp") as? String
        {
            self.arrMsgTime.add(Int(time)!)
        }
        else if let time = snapShotValue.value(forKey: "timestamp") as? Int
        {
            self.arrMsgTime.add(time)
        }
        if let thumb = snapShotValue.value(forKey: "imageThumb") as? String
        {
            self.arrMsgPicThumb.add(thumb)
        }
        else
        {
            self.arrMsgPicThumb.add("")
        }
        if let urltype = snapShotValue.value(forKey: "messageImagePath") as? String
        {
            self.arrMsgPic.add(urltype)
        }
        else
        {
            self.arrMsgPic.add("")
        }
        if let audio = snapShotValue.value(forKey: "messageAudioFile") as? String
        {
            self.arrMsgAudio.add(audio)
        }
        else
        {
            self.arrMsgAudio.add("")
        }
        if let lat = snapShotValue.value(forKey: "latitude") as? Double
        {
            self.arrMsgLat.add(lat)
        }
        else
        {
            self.arrMsgLat.add("")
        }
        if let long = snapShotValue.value(forKey: "longitude") as? Double
        {
            self.arrMsgLong.add(long)
        }
        else
        {
            self.arrMsgLong.add("")
        }
        if let address = snapShotValue.value(forKey: "address") as? String
        {
            self.arrMsgAddress.add(address)
        }
        else
        {
            self.arrMsgAddress.add("")
        }
        self.arrMsgId.add(snapshotkey)
        
        if let msgStatus = snapShotValue.value(forKey: "messageStatus") as? Int
        {
            if msgStatus != SEEN && msgStatus != MESSAGE_DELETED
            {
                if defaults.value(forKey: "uid") as! String != snapShotValue.value(forKey: "from") as! String
                {
                    self.arrMsgStatus.add(SEEN)
                   MessagesDB.child(groupId).child(self.touid).child(snapshotkey).queryOrderedByKey().observe(.value) { (snapshot) in
                        if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                            if snapShot.count > 0
                            {
                               
                               MessagesDB.child(self.groupId).child(self.touid).child(snapshotkey).updateChildValues(["messageStatus": SEEN])
                            }
                        }
                    }
                }
                else
                {
                    self.arrMsgStatus.add(msgStatus)
                }
            }
            else
            {
                self.arrMsgStatus.add(msgStatus)
            }
        }
    }
    //MARK:- When New Message RECEIVE
    func funReceiveMessage()
    {
        var tempcount = 0
        MessagesDB.child(groupId).child(fromuid).observe(.childAdded) { (snapshot : DataSnapshot) in
            
            if snapshot.childrenCount > 0
            {
                if self.isviewloaad == 0
                {
                    tempcount = tempcount + 1
                    if tempcount == self.totalmessagecount
                    {
                        self.isviewloaad = 1
                    }
                    return
                }
                let snapShotValue = snapshot.value as! NSDictionary
                print(snapShotValue)
                self.arrMsgId.add(snapshot.key)
                self.arrMsgFomid.add(snapShotValue.value(forKey: "from") as! String)
                if let msgStatus = snapShotValue.value(forKey: "messageStatus") as? Int
                {
                    if msgStatus != SEEN
                    {
                        if self.fromuid != snapShotValue.value(forKey: "from") as? String
                        {
                            MessagesDB.child(self.groupId).child(self.touid).child(snapshot.key).updateChildValues(["messageStatus": SEEN])
                            self.arrMsgStatus.add("\(SEEN)")
                            self.isdeliver(messageStatus: SEEN)
                            self.isdeliverWhenMsgScreenOpen()
                        }else
                        {
                            self.arrMsgStatus.add(msgStatus)
                        }
                    }else
                    {
                        self.arrMsgStatus.add(msgStatus)
                    }
                }
                
                self.arrMsg.add(snapShotValue.value(forKey: "message") as! String)
                if let type = snapShotValue.value(forKey: "messageType") as? String
                {
                    self.arrMsgType.add(type)
                }
                else if let type = snapShotValue.value(forKey: "messageType") as? Int
                {
                    self.arrMsgType.add(type)
                }
                if let time = snapShotValue.value(forKey: "timestamp") as? String
                {
                    self.arrMsgTime.add(Int(time)!)
                }
                else if let time = snapShotValue.value(forKey: "timestamp") as? Int
                {
                    self.arrMsgTime.add(time)
                }
                if let thumb = snapShotValue.value(forKey: "imageThumb") as? String
                {
                    self.arrMsgPicThumb.add(thumb)
                }
                else
                {
                    self.arrMsgPicThumb.add("")
                }
                if let urltype = snapShotValue.value(forKey: "messageImagePath") as? String
                {
                    self.arrMsgPic.add(urltype)
                }
                else
                {
                    self.arrMsgPic.add("")
                }
                if let audio = snapShotValue.value(forKey: "messageAudioFile") as? String
                {
                    self.arrMsgAudio.add(audio)
                }
                else
                {
                    self.arrMsgAudio.add("")
                }
                self.arrImagePlayPause.append("play")
                self.arrTotalAudioTime.append("00:00")
                if let lat = snapShotValue.value(forKey: "latitude") as? Double
                {
                    self.arrMsgLat.add(lat)
                }
                else
                {
                    self.arrMsgLat.add("")
                }
                if let long = snapShotValue.value(forKey: "longitude") as? Double
                {
                    self.arrMsgLong.add(long)
                }
                else
                {
                    self.arrMsgLong.add("")
                }
                if let address = snapShotValue.value(forKey: "address") as? String
                {
                    self.arrMsgAddress.add(address)
                }
                else
                {
                    self.arrMsgAddress.add("")
                }
                //self.tablev.reloadData()
                let indexPath = IndexPath(row: self.arrMsgType.count-1, section: 0)
                //MARK:- Add new row in table view
                self.tablev.beginUpdates()
                self.tablev.insertRows(at: [IndexPath(row: self.arrMsgType.count-1, section: 0)], with: .automatic)
                self.tablev.endUpdates()
                if self.arrMsgType.count > 0
                {
                    self.scrolltobottom(indexpath: indexPath)
                }
            }
        }
    }
    
    //MARK:- When other user is Typing or Recording His Status will work Accrodingly
    func funUserActivityStatus()
    {
        ChatDB.child(fromuid).child(groupId).observe(.childChanged, with: { (snapshot) in
            if snapshot.key == "typing"
            {
                if snapshot.value as! Int == TYPING
                {
                    self.updateTyping()
                }
                else if snapshot.value as! Int == RECORDING
                {
                    self.updateRecording()
                }
                else
                {
                    self.updateOnline()
                }
            }
            else if snapshot.key == "lastMessageStatus"
            {
                //MARK:- If user ask for if message NOT_DELIVERED we will update it to seen
                if snapshot.value as! Int == NOT_DELIVERED
                {
                    //self.isdeliver(messageStatus: SEEN)
                }
                else if snapshot.value as! Int == SENT
                {
                    //MARK:- Response for other user that message has been Seen
                    self.isdeliver(messageStatus: SEEN)
                }
            }
        })
    }
    
    //MARK:- When message DELIVER or SEEN
    func funMessageDBDeliveryStatus()
    { MessagesDB.child(groupId).child(fromuid).queryOrderedByKey().observe(.childChanged) { (snapshot) in
            print(snapshot)
            //
            if self.fromuid == (snapshot.value as! NSDictionary).value(forKey: "from") as! String
            {
                if self.arrMsgId.contains(snapshot.key) == true
                {
                    let index = self.arrMsgId.index(of: snapshot.key)
                    if let status = (snapshot.value as! NSDictionary).value(forKey: "messageStatus") as? Int
                    {
                        self.arrMsgStatus[index] = status
                        let indexPath = IndexPath(row: index, section: 0)
                        DispatchQueue.main.async {
                            self.tablev.reloadRows(at: [indexPath], with: .none)
                        }
                    }
                }
            }
            else{
                if self.arrMsgId.contains(snapshot.key) == true
                {
                    let index = self.arrMsgId.index(of: snapshot.key)
                    if let status = (snapshot.value as! NSDictionary).value(forKey: "messageStatus") as? Int
                    {
                        if status == MESSAGE_DELETED
                        {
                            self.arrMsgStatus[index] = status
                            let indexPath = IndexPath(row: index, section: 0)
                            DispatchQueue.main.async {
                                self.tablev.reloadRows(at: [indexPath], with: .none)
                            }
                        }
                    }
                }
            }
        }
    }
    
    func isTypingOrRecording(isTypingOrRecording: Int)
    {
        ChatDB.child(touid).child(groupId).observe(.value, with: { (snapshot) in
            ChatDB.child(self.touid).child(self.groupId).removeAllObservers()
            
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                if snapShot.count > 0{
                    ChatDB.child(self.touid).child(self.groupId).updateChildValues(["typing": isTypingOrRecording], withCompletionBlock: {
                        error, snapshot in
                        if error != nil
                        {
                            print(error?.localizedDescription as Any)
                            print("Error in  typing")
                        }
                        else
                        {
                            print("is typing")
                        }
                    })
                }
            }
        })
    }
    
    
    //MARK:- Run Time Message Delivery Status
    func isdeliver(messageStatus: Int)
    {
        ChatDB.child(touid).child(groupId).observe(.value, with: { (snapshot) in
            ChatDB.child(self.touid).child(self.groupId).removeAllObservers()
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                if snapShot.count > 0{
                   
                    if let lastmessagestatus = (snapshot.value as! NSDictionary).value(forKey: "lastMessageStatus") as? Int
                    {
                        if lastmessagestatus != SEEN //&& lastmessagestatus != MESSAGE_DELETED
                        {
                           
                            ChatDB.child(self.touid).child(self.groupId).updateChildValues(["lastMessageStatus": messageStatus], withCompletionBlock: {
                                error, snapshot in
                                if error != nil
                                {
                                    print(error?.localizedDescription as Any)
                                    print("Error in  typing")
                                }
                                else
                                { //ChatDB.child(self.touid).child(self.groupId).updateChildValues(["typing": istyping])
                                    print("is Deliver")
                                }
                            })
                        }
                    }
                }
            }
        })
    }
    
    //MARK:- Run Time Message Delivery Status
    func isSelfdeliver(messageStatus: Int)
    {
        ChatDB.child(fromuid).child(groupId).observe(.value, with: { (snapshot) in
            ChatDB.child(self.fromuid).child(self.groupId).removeAllObservers()
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                if snapShot.count > 0{
                    
                    if let lastmessagestatus = (snapshot.value as! NSDictionary).value(forKey: "lastMessageStatus") as? Int
                    {
                        if lastmessagestatus != SEEN //&& lastmessagestatus != MESSAGE_DELETED
                        {
                            
                            ChatDB.child(self.fromuid).child(self.groupId).updateChildValues(["lastMessageStatus": messageStatus], withCompletionBlock: {
                                error, snapshot in
                                if error != nil
                                {
                                    print(error?.localizedDescription as Any)
                                    print("Error in  typing")
                                }
                                else
                                { //ChatDB.child(self.touid).child(self.groupId).updateChildValues(["typing": istyping])
                                    print("is Deliver")
                                }
                            })
                        }
                    }
                }
            }
        })
    }
    //MARK:- When Chat Screen Open
    func isdeliverWhenMsgScreenOpen()
    {
        ChatDB.child(fromuid).child(groupId).observe(.value, with: { (snapshot) in
            ChatDB.child(self.fromuid).child(self.groupId).removeAllObservers()
            
            self.funUserActivityStatus()
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                //MARK:- When Chat Screen Run Frist time tells other use that message has been received
                self.isdeliver(messageStatus: SEEN)
                if snapShot.count > 0 {
                    if ((snapshot.value as! NSDictionary).value(forKey: "lastMessageStatus") as? Int) != nil
                    {
                        ChatDB.child(self.fromuid).child(self.groupId).updateChildValues(["unSeenCount": 0], withCompletionBlock: {
                            error, snapshot in
                            if error != nil
                            {
                                print(error?.localizedDescription as Any)
                                print("Error in  typing")
                            }
                            else
                            {
                                print("is Deliver")
                            }
                        })
                        }
                 
                 
                }
            }
        })
    }
    
    //MARK:- Upload image or file to Firebase Storage
    func uploadMedia(type: Int, completion: @escaping (_ url: String?) -> Void) {
        andicator.startAnimating()
        // let storageRef = Storage.storage().reference().child("UserPictures")
        let timespam = Date().currentTimeMillis()!
        var filename = ""
        var uploadData = Data()
        if type == IMAGE
        {
            filename = "UserMsgPictures/\("\(String(describing: timespam)))").png"
            uploadData = selectedimage.jpegData(compressionQuality: 0.3)!
        }
        else if type == AUDIO
        {
            filename = "UserMsgAudio/\("\(String(describing: timespam))")audio.mp4"
            uploadData = audiodata
        }
        // if let uploadData = self.imgvprofile.image?.jpegData(compressionQuality: 0.4) {
        if uploadData.isEmpty !=  true{
            refStorageFireBase.child(filename).putData(
                uploadData ,
                metadata: nil) {
                    (snapshot, error) in
                    self.andicator.stopAnimating()
                    if error != nil {
                        print("error")
                        completion("Error Occured in upload picture")
                    } else {
                        print(snapshot as Any)
                        //MARK:- this link is just dummy image
                        // https://firebasestorage.googleapis.com/v0/b/chatapp-de622.appspot.com/o/Message_Images%2F-LY_lpC2UxBf7lQ3VPEA_thumb.jpg?alt=media&token=193523e9-62c8-4db1-9b5f-ee0c626a8d22
                        refStorageFireBase.child(filename).downloadURL { (url, error) in
                            guard let downloadURL = url else {
                                completion("Uh-oh, an error occurred! try again.")
                                return
                            }
                            //MARK:- This code is for just Example and testing the url is showing in App or not
                            //                            let imageg = UIImageView()
                            //                            imageg.kf.setImage(with: downloadURL)
                            //
                            //                            self.view.addSubview(imageg)
                            //                            imageg.bounds = self.view.bounds
                            
                            completion("\(downloadURL)")
                        }
                        
                        //completion((metadata?.downloadURL()?.absoluteString)!)
                        // your uploaded photo url.
                    }
            }
        }
    }
    
    func funGetMessageCount(completion: @escaping (_ unSeenCount: Int?) -> Void) {
        
        var unSeenCount = 0
        if groupId == ""
        {
            completion(1)
            return
        }
        ChatDB.child(touid).child(groupId).observe(.value, with: { (snapshot) in
            ChatDB.child(self.touid).child(self.groupId).removeAllObservers()
            if let snapShot = snapshot.children.allObjects as? [DataSnapshot] {
                if snapShot.count > 0{
                    if let tempunSeenCount = (snapshot.value as! NSDictionary).value(forKey: "unSeenCount") as? Int
                    {
                        unSeenCount = tempunSeenCount
                    }
                    else if let tempunSeenCount = (snapshot.value as! NSDictionary).value(forKey: "unSeenCount") as? String
                    {
                        unSeenCount = Int(tempunSeenCount)!
                    }
                }
                unSeenCount = unSeenCount + 1
                completion(unSeenCount)
            }
        })
    }
    
    
    //MARK:- Message Delivery Status Update When App Receive New Message
    func funMessageStatusUpdateRunTime()
    {
        
    }
    
    
}//MARK:-Class End



//Load image from url
//            let url = URL(string: userimgurlforcallscreen)
//            let request: URLRequest = URLRequest(url: url!)
//            let session = URLSession.shared
//            let task = session.dataTask(with: request as URLRequest, completionHandler: {data, response, error -> Void in
//                let error = error
//                let data = data
//                if error == nil {
//                    // Convert the downloaded data in to a UIImage object
//                    let image = UIImage(data: data!)
//                    // Update the cell
//                    DispatchQueue.main.async{
//                        cell.imgv.image = image
//                    }
//                }
//            })
//            task.resume()





extension Date {
    func currentTimeMillis() -> Int64! {
        return Int64(self.timeIntervalSince1970 * 1000)
    }
}






